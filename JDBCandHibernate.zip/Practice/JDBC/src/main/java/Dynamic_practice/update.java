package Dynamic_practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class update {
	public static void main(String[] args) throws SQLException {
		Scanner scanner=new Scanner(System.in);
		
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/Villege","root","ROOT");

	     PreparedStatement preparedStatement=connection.prepareStatement("update home set name=? where id=?");
	     System.out.println("Enter id");
	     preparedStatement.setInt(2, scanner.nextInt());
	     System.out.println("Enter name");
	     preparedStatement.setString(1,scanner.next());
	     preparedStatement.execute();
	     connection.close();
	     System.out.println("update values");
	     
	    
	}
}
