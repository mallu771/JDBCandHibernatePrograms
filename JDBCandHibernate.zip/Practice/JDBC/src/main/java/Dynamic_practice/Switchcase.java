package Dynamic_practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Switchcase {
public static void main(String[] args) throws SQLException {

	Scanner scanner=new Scanner(System.in);
	
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","ROOT");
    boolean flag=true;
    while(flag){
    	System.out.println("1.Add the Vehicle/n2.Update the vehicle/n3.delete the vehicle/n4.fetch the vehicle details througth vechicle no/n5.fetch all the vehicle details/n6.delete all the vehicle/n7.exit");
    	
    	switch(scanner.nextInt())
    	{
    	case 1:
    	{
    		PreparedStatement preparedStatement=connection.prepareStatement("insert into vehicle_m values(?,?,?,?,?)");
    		System.out.println("Enter vehicle no");
    		preparedStatement.setInt(1, scanner.nextInt());
    		System.out.println("Enter vehicle name");
    		preparedStatement.setString(2, scanner.next());
    		System.out.println("Enter vehicle model");
    		preparedStatement.setString(3, scanner.next());
    		System.out.println("Enter vehicle regno");
    		preparedStatement.setInt(4, scanner.nextInt());
    		System.out.println("Enter vehicle color");
    		preparedStatement.setString(5, scanner.next());
    		preparedStatement.execute();
    	}
    	break;
    	case 2:
    	{
    		PreparedStatement preparedStatement=connection.prepareStatement("update vehicle_m set vehicle_name=? where vehicle_no=?");
    		System.out.println("Enter vehicle no");
    		preparedStatement.setInt(2, scanner.nextInt());
    		System.out.println("Enter vehicle name");
    		preparedStatement.setString(1, scanner.next());
    		preparedStatement.execute();
    	}
    	break;
    	case 3:
    	{
    		PreparedStatement preparedStatement=connection.prepareStatement("delete from vehicle_m where vehicle_no=?");
    		System.out.println("Enter vehicle no");
    		preparedStatement.setInt(1, scanner.nextInt());
    		preparedStatement.execute();
    	}
    	break;
    	case 4:
    	{
    		PreparedStatement  preparedStatement=connection.prepareStatement("select * from vehicle_m where vehicle_no=?");
    		System.out.println("Enter vehicle no");
    		preparedStatement.setInt(1, scanner.nextInt());
    		ResultSet e=preparedStatement.executeQuery();
            e.next();
            System.out.println(e.getInt(1)+" "+e.getString(2)+" "+e.getString(3)+" "+e.getInt(4)+" "+e.getString(5));
    	}
    	break;
    	case 5:
    	{

    		PreparedStatement  preparedStatement=connection.prepareStatement("select * from vehicle_m");
    	   ResultSet e=preparedStatement.executeQuery();
          while(e.next())
           {
            System.out.println(e.getInt(1)+" "+e.getString(2)+" "+e.getString(3)+" "+e.getInt(4)+" "+e.getString(5));
    	}
    	}
           break;
           case 6:
           {
        	   PreparedStatement preparedStatement=connection.prepareStatement("delete from vehicle_m");
        	   preparedStatement.execute();
           }
           break;
           case 7:
           {
        	   System.out.println("thank you");
        	  
           }
           break;
  
           default:
           {
        	   System.out.println("Invalid number");
        	   break;
           }
    }
    }
    	connection.close();
    	
      
}

}

