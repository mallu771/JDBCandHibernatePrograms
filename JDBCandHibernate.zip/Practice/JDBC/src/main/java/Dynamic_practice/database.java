package Dynamic_practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class database {
public static void main(String[] args) throws SQLException {
	Scanner scanner=new Scanner(System.in);
	
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/Villege","root","ROOT");
    Statement statement=connection.createStatement();
//     PreparedStatement preparedStatement=connection.prepareStatement("insert into home values(?,?)");
//     System.out.println("Enter id");
//     preparedStatement.setInt(1, scanner.nextInt());
//     System.out.println("Enter name");
//     preparedStatement.setString(2,scanner.next());
//     preparedStatement.execute();
     connection.close();
     System.out.println("insert values");
     
    
}

}
