package Springdefe;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

//@Component
@Primary
public class Airtel implements Sim{
	public  void getSimdetails() {
		
		
		System.out.println("This is Airtel sim");
	}

}
