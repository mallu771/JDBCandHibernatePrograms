
package Springdefe;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

//@Component
//@Primary
public class Jio implements Sim {

public  void getSimdetails() {
		
		
		System.out.println("This is jio sim");
	}
static Jio createSim(String a){
	
	return new Jio();
	
}
}
