package Springdefe;

import org.springframework.stereotype.Component;

//@Component
public interface Sim {

	void getSimdetails();

}
