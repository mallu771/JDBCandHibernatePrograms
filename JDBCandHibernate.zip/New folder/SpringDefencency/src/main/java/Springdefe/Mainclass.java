package Springdefe;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class Mainclass {

	public static void main(String[] args) {
		
		ApplicationContext context=new AnnotationConfigApplicationContext(Settingclass.class);
		Mobile mobile=(Mobile) context.getBean("mobile");
//		System.out.println(mobile);
		mobile.sim.getSimdetails();
	}
}
