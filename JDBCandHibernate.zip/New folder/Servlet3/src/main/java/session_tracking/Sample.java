package session_tracking;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/sample")
public class Sample extends HttpServlet{
     @Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	int x=10;
    	int y=15;
//    	req.setAttribute("x", x);
//    	req.getRequestDispatcher("Tester").forward(req, res);
    	res.sendRedirect("Tester?x="+x+"&y="+y);
    	
    }
}
