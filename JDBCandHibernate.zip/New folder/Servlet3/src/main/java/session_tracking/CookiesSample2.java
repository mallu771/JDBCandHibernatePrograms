package session_tracking;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookie2")
public class CookiesSample2 extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try{
		Cookie[] cookies=req.getCookies();
		for(Cookie cookie: cookies)
		{
			if(cookie.getName().equals("msg")||cookie.getName().equals("a")||cookie.getName().equals("b"))
			res.getWriter().print("<h1>"+cookie.getValue()+"</h1>");
		
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		res.getWriter().print("<h1>Logout</h1>");
		
		
		
	}

}
