package session_tracking;

import java.io.IOException;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Tester extends HttpServlet {
  @Override
protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
  {
	 int x=Integer.parseInt(req.getParameter("x"));
	 int y=Integer.parseInt(req.getParameter("y"));
//	int x=(Integer)req.getAttribute("x");
	res.getWriter().print("<h1>"+x+" "+y+"</h1>");
}
}
