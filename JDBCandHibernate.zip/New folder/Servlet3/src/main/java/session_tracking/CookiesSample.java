package session_tracking;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookie1")
public class CookiesSample extends HttpServlet {

	  @Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		  res.getWriter().print("<h1>Login Successful</h1>");
		  String msg="mallu";
		  
		  Cookie cookie=new Cookie("msg", msg);
		  Cookie cookie2=new Cookie("a", "100");
		  Cookie cookie3=new Cookie("b", "300");
		
		  cookie.setMaxAge(8);
		  cookie2.setMaxAge(9);
		  cookie3.setMaxAge(10);
		  
		  res.addCookie(cookie3);
		  res.addCookie(cookie2);
		  res.addCookie(cookie);
		  
		  res.sendRedirect("cookie2");
	}
}
