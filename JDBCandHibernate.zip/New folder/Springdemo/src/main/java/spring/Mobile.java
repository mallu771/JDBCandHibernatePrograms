package spring;

import lombok.Data;

@Data
public class Mobile {

	int ram;
	String model;
	String color;
	double prize;
//	public int getRam() {
//		return ram;
//	}
//	public void setRam(int ram) {
//		this.ram = ram;
//	}
//	public String getModel() {
//		return model;
//	}
//	public void setModel(String model) {
//		this.model = model;
//	}
//	public String getColor() {
//		return color;
//	}
//	public void setColor(String color) {
//		this.color = color;
//	}
//	public double getPrize() {
//		return prize;
//	}
//	public void setPrize(double prize) {
//		this.prize = prize;
//	}
	Sim sim;
	public Sim getSim() {
		return sim;
	}
	public void setSim(Sim sim) {
		this.sim = sim;
	}
	@Override
	public String toString() {
		return "Mobile [ram=" + ram + ", model=" + model + ", color=" + color + ", prize=" + prize + ", sim=" + sim
				+ "]";
	}
	
}
