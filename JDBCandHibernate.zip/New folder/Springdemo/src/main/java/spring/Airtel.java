package spring;

public class Airtel implements Sim
{
@Override
public String toString() {
	return "This Airtel sim";
}
}
