package spring;

public class Mainclass {

	public static void main(String[] args) {
		Mobile mobile=new Mobile();
		
		mobile.setColor("red");
		mobile.setModel("radmi");
		mobile.setPrize(25371.782);
		mobile.setRam(5);
		mobile.setSim(new Airtel());
		System.out.println(mobile);
	}

}
