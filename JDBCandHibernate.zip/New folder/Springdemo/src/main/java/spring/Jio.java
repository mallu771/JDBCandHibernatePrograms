package spring;

public class Jio implements Sim {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "this jio sem";
	}
}
