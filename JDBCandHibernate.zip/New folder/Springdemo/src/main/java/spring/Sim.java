package spring;

public interface Sim {

}
