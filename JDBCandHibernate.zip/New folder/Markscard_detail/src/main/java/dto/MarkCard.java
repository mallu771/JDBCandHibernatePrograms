package dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

//import lombok.Data;

@Entity
//@Data
public class MarkCard {
@Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
int id;
String standard;
double science;
double maths;
double english;
double percentage;
String result;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getStandard() {
	return standard;
}
public void setStandard(String standard) {
	this.standard = standard;
}
public double getScience() {
	return science;
}
public void setScience(double science) {
	this.science = science;
}
public double getMaths() {
	return maths;
}
public void setMaths(double maths) {
	this.maths = maths;
}
public double getEnglish() {
	return english;
}
public void setEnglish(double english) {
	this.english = english;
}
public double getPercentage() {
	return percentage;
}
public void setPercentage(double percentage) {
	this.percentage = percentage;
}
public String getResult() {
	return result;
}
public void setResult(String result) {
	this.result = result;
}

}
