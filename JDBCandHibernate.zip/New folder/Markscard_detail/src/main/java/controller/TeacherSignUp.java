package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.TeacherDao;
import dto.Teacher;

@WebServlet("/teacherSignup")
public class TeacherSignUp extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	Teacher teacher=new Teacher();
	
		teacher.setEmail(req.getParameter("email"));
		teacher.setEmpid(req.getParameter("eid"));
		teacher.setMobile(Long.parseLong(req.getParameter("phone")));
	
		teacher.setName(req.getParameter("name"));
		teacher.setPassword(req.getParameter("password"));
		teacher.setSubject(req.getParameter("subject"));
		
		TeacherDao dao=new TeacherDao();
		try{
		dao.saveTeacher(teacher);
		res.getWriter().print("<h1>Teacher Acccount Success created</h1>");
		req.getRequestDispatcher("login.html").include(req, res);
		}
		catch (Exception e) {
			res.getWriter().print("<h1>Email /Phone Number Exits</h1>");
			req.getRequestDispatcher("teacherSignup.html").include(req, res);
		}
	}
}
