package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.query.criteria.internal.compile.CriteriaQueryTypeQueryAdapter;

import dto.Student;

public class StudentDao {

	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
    EntityTransaction entityTransaction=entityManager.getTransaction();
	

	public void saveStudent(Student student)
	{
		
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
	
		
	}
	
	public Student findStudent(String email)
	{
		List<Student> list=entityManager.createQuery("select x Student x where email=?1").getResultList();
		
	}
}
