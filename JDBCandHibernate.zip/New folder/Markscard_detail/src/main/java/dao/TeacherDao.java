package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.exception.ConstraintViolationException;

import dto.Teacher;
import sun.security.krb5.internal.crypto.EType;

public class TeacherDao {

	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	

	public void saveTeacher(Teacher teacher)
	{
		
		entityTransaction.begin();
		entityManager.persist(teacher);
		entityTransaction.commit();
	
		
	}
}
