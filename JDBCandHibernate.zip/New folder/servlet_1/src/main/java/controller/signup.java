package controller;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;

import dao.userdao;
import dto.user;

//@WebServlet(urlPatterns="/signup",initParams={
//		@WebInitParam(name="cname", value="Mangalore"),
//@WebInitParam(name="cbranch", value="Mangalore")	
@WebServlet("/signup")
//})
public class signup extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
//	String name=req.getParameter("name");
//	long phno=Long.parseLong(req.getParameter("phno"));
//	String email=req.getParameter("email");
//	String password=req.getParameter("password");
//	String gender=req.getParameter("gender");
//	String address=req.getParameter("address");
//  res.getWriter().print("<h1>Name:"+name+"</h1><br>");
//  res.getWriter().print("<h1>Phno:"+phno+"</h1><br>");
//  res.getWriter().print("<h1>Email:"+email+"</h1><br>");
//  res.getWriter().print("<h1>Password:"+password+"</h1><br>");
//  res.getWriter().print("<h1>Gender:"+gender+"</h1><br>");
//  res.getWriter().print("<h1>Address:"+address+"</h1><br>");
		
//		String cname=getServletConfig().getInitParameter("cname");
//		String cbranch=getServletConfig().getInitParameter("cbranch");
	user user1=new user();
	user1.setName(req.getParameter("name"));
	user1.setAddress(req.getParameter("address"));
	user1.setEmail(req.getParameter("email"));
	user1.setGender(req.getParameter("gender"));
	user1.setPassword(req.getParameter("password"));
	user1.setPhno(Long.parseLong(req.getParameter("phno")));
	
	userdao dao=new userdao();
	try {
		
		dao.save(user1);
//		res.getWriter().print("<h1>Account success"+cname+" and "+cbranch+" </h1>");
		res.getWriter().print("<h1>Account success</h1>");
//		RequestDispatcher rd=req.getRequestDispatcher("login.html");
//		req.getRequestDispatcher("login.html").forward(req,res);
		req.getRequestDispatcher("login.html").include(req,res);
	} catch (Exception e) {
		res.getWriter().print("<h1>Email already exit </h1>");
//		RequestDispatcher rd=req.getRequestDispatcher("login.html");
//		req.getRequestDispatcher("login.html").forward(req,res);
		req.getRequestDispatcher("signup.html").include(req,res);
	}
	
}

}
