package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.userdao;
import dto.user;
@WebServlet("/edit")
public class Edit extends HttpServlet
{

		@Override
		protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			user user1=new user();
			user1.setPhno(Integer.parseInt(req.getParameter("id")));
			user1.setName(req.getParameter("name"));
			user1.setAddress(req.getParameter("address"));
			user1.setEmail(req.getParameter("email"));
			user1.setGender(req.getParameter("gender"));
			user1.setPassword(req.getParameter("password"));
			user1.setPhno(Long.parseLong(req.getParameter("phno")));
			
			userdao dao=new userdao();
			dao.edit(user1);
			List<user> list=dao.fetchAll();
			req.setAttribute("list", list);
			req.getRequestDispatcher("Result.jsp").include(req,res);  
			
		}
}
