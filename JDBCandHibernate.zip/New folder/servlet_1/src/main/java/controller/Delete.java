package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.userdao;
import dto.user;

@WebServlet(urlPatterns="/delete")
public class Delete extends HttpServlet
{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	  if(req.getSession().getAttribute("id")==null)
	  {
		  res.getWriter().print("<h1>Invalid login again</h1>");
		  req.getRequestDispatcher("login.html").include(req, res);
	  }
	  else{
		String email=req.getParameter("email");
//	  res.getWriter().print("<h1>The row deleted succesfully</h1>");
//	 
	  userdao dao=new userdao();
	  user user1=dao.find(email);
	  dao.delete(user1);
//	
//	  req.getRequestDispatcher("Result.jsp").forward(req, res);
	    
	}}
}











































