package controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.userdao;
import dto.user;
//@WebServlet(urlPatterns="/login",initParams={
//		@WebInitParam(name="cbranch", value="raj"),
//		@WebInitParam(name="cname", value="Bengalore")
//})
@WebServlet("/login")

public class login extends HttpServlet{

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String cname=getServletConfig().getInitParameter("cname");
//		String cbranch=getServletContext().getInitParameter("cbranch");
		String cbranch=getServletConfig().getInitParameter("cbranch");

		
		String email=req.getParameter("email");
		String password=req.getParameter("password");
//		res.getWriter().print("<h1>email"+email+"</h1><br>");
//		res.getWriter().print("<h1>password"+email+"</h1><br>");
//		multiple imports using cntrl+o
//		System.out.println(email+password);
		userdao dao=new userdao();
		user user1=dao.find(email);
		
		
		if(user1==null)
		{
			res.getWriter().print("<h1>Invalid email id</h1>");
//			req.getRequestDispatcher("login.html").forward(req,res);
			req.getRequestDispatcher("login.html").include(req,res);
		}
		else
		{
			if(user1.getPassword().equals(password))
			{
				req.getSession().setAttribute("id", "tamillllu");
//        			res.getWriter().print("<h1>Login successfull "+cname+" and "+cbranch+"</h1>");
//			
////			    res.sendRedirect("http://www.youtube.com");
//        		
//        			List<user> list=dao.fetchAll();
//        			for(user u:list)
//        			{
//        				res.getWriter().print("<h1>UserName : "+u.getName()+"</h1>");
//        				res.getWriter().print("<h1>UserEmail : "+u.getEmail()+"</h1>");
//        				res.getWriter().print("<h1>UserMobile : "+u.getPhno()+"</h1>");
//        				res.getWriter().print("<h1>UserPassword : "+u.getPassword()+"</h1>");
//        				res.getWriter().print("<h1>UserAddress : "+u.getAddress()+"</h1>");
//        				res.getWriter().print("<h1>UserGender : "+u.getGender()+"</h1>");
//        				res.getWriter().print("...............................");
//        			}
//        			res.getWriter().print("<h1>................................................</h1>");
//        		res.getWriter().print("<table border=\1\">"+"<tr>"+
//        			
//        				"<th>UserName:</th>"+
//        				"<th>Email:</th>"+
//        				"<th>Gender:</th>"+
//        				"<th>Phno:</th>"+
//        				"<th>Address:</th>"+
//        				"<th>Password:</th>"+"</tr>");
//        			List<user> list1=dao.fetchAll();
//        			for(user u:list)
//        			{
//        				res.getWriter().print("<tr><th>"+u.getName()+"</th>");
//        				res.getWriter().print("<th> "+u.getEmail()+"</th>");
//        		        res.getWriter().print("<th>"+u.getPhno()+"</th>");
//        				res.getWriter().print("<th>"+u.getPassword()+"</th>");
//        				res.getWriter().print("<th> "+u.getAddress()+"</th>");
//        				res.getWriter().print("<th> "+u.getGender()+"</th></tr>");
//        				res.getWriter().print("...............................");
//        			}
				List<user> list =dao.fetchAll();
				req.setAttribute("list",list);
				req.getRequestDispatcher("Result.jsp").forward(req, res);
        		
			}
			else{
//				res.setContentType("text/html");
				res.getWriter().print("<h1>Invalid password</h1>");
//			    req.getRequestDispatcher("login.html").include(req,res);
			}
		}
	}

	}
		
