package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dto.user;

public class userdao {
EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
EntityManager entityManager=entityManagerFactory.createEntityManager();
EntityTransaction entityTransaction=entityManager.getTransaction();
 public void save(user user1)
 {
	 entityTransaction.begin();
	 entityManager.persist(user1);
	 entityTransaction.commit();
 }
public user find(String email) {
	
//	return entityManager.find(user.class, email);
	List<user> user1=entityManager.createQuery("select x from user x where email=?1").setParameter(1, email).getResultList();
	if(user1.isEmpty())
	{
		return null;
	}
	else
		return user1.get(0);
}

public List<user> fetchAll()
{
	return entityManager.createQuery("select a from user a").getResultList();
}
public void delete(user user1)
{
	entityTransaction.begin();
	entityManager.remove(user1);
	entityTransaction.commit();
}
public void edit(user user1)
{	
	entityTransaction.begin();
	entityManager.merge(user1);
	entityTransaction.commit();
}

}
