package spring_b_a;

import org.apache.naming.factory.BeanFactory;

public class Sample {

	public static void main(String[] args) {
         
		BeanFactory factory=new x
	    Bike bike =((bike) factory).getBean("bike");
	    System.out.println(bike);
	}
}
