package springpractice;

public interface Sim {

}
