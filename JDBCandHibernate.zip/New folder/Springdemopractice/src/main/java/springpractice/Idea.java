package springpractice;

public class Idea implements Sim {

	@Override
	public String toString() {
		return "this is idea sim";
	}

	
}
