package springpractice;

import lombok.Data;

@Data
public class Mobile {

	
	int id;
	String model;
	String color;
	long prize;
	Sim sim;
	
	
}
