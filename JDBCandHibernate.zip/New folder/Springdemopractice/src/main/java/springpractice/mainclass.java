package springpractice;

public class mainclass {

	public static void main(String[] args) {
		Mobile mobile=new Mobile();
		mobile.setId(100);
		mobile.setModel("redmi");
		mobile.setColor("silver");
		mobile.setPrize(578332);
		mobile.setSim(new Idea());
		System.out.println(mobile);
	}
}
