package springpractice;

public class jio implements Sim {

	@Override
	public String toString() {
		return "This is jio sim";
	}

	
}
