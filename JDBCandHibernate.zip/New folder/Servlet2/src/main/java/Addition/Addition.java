package Addition;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Addition")
public class Addition extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int value1=Integer.parseInt(req.getParameter("value1"));
		int value2=Integer.parseInt(req.getParameter("value2"));
		int res=value1+value2;
//		System.out.println(res);
		resp.getWriter().print("<h1>The addtion "+value1+"and"+value2+" number is:"+res+"</h1>");
		req.setAttribute("res", res);
		req.getRequestDispatcher("square").include(req, resp);
	}
}
