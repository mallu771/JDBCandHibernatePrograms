package Addition;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cube")
public class cube extends HttpServlet {
  @Override
protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	  int res3=(Integer)req.getAttribute("res2");
	  resp.getWriter().print("<h1>The Cube of "+res3+" is: "+(res3*res3*res3)+" </h1>");
}
}
