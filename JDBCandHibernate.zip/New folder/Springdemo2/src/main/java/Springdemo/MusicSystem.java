package Springdemo;

public class MusicSystem {

	@Override
	public String toString() {
		return "this music system"
;		
	}

	
}
