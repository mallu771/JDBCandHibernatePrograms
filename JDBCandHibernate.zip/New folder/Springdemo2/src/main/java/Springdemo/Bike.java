package Springdemo;

public class Bike {
	
//	Bike(){
//		System.out.println("object created");
//	
//	}
	String company;
	String cc;
	String color;
//	public Bike(String company, String cc, String color) {
//		super();
//		this.company = company;
//		this.cc = cc;
//		this.color = color;
//	}
	MusicSystem system;
	public Bike(){
		
	}
//	@Override
//	public String toString() {
//		return "Bike [company=" + company + ", cc=" + cc + ", color=" + color + "]";
//	}
	public Bike(String company, String cc, String color, MusicSystem musicSystem) {
		super();
		this.company = company;
		this.cc = cc;
		this.color = color;
		this.system = system;
	}
	@Override
	public String toString() {
		return "Bike [company=" + company + ", cc=" + cc + ", color=" + color + ", system=" + system + "]";
	}
	

}
