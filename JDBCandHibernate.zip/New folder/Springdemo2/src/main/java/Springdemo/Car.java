package Springdemo;

import lombok.Data;

//@Data
public class Car {

	String brand;
	String color;
	double price;
	MusicSystem system;
	//why we  not write here because doesn't class.file 
	//because we write property in .xml file
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
public MusicSystem getSystem() {
		return system;
	}
	public void setSystem(MusicSystem system) {
		this.system = system;
	}
	//	@Override
//	public String toString() {
//		return "Car [brand=" + brand + ", color=" + color + ", price=" + price + "]";
//	}
	@Override
	public String toString() {
		return "Car [brand=" + brand + ", color=" + color + ", price=" + price + ", system=" + system + "]";
	}

}
