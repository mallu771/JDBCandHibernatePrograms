package Springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Sample {
	public static void main(String[] args) {
     ApplicationContext context=new ClassPathXmlApplicationContext("/Springdemo/Myconfig.xml");
//     Bike bike=(Bike) context.getBean("bike");
//     System.out.println(bike);
//     Bike bike1=(Bike) context.getBean("bike");
//     System.out.println(bike1); 
     Car car= (Car) context.getBean("car");
     System.out.println(car);
     Bike bike=(Bike) context.getBean("bike");
     System.out.println(bike);
     MusicSystem system=(MusicSystem) context.getBean("s");
     System.out.println(system);
	}
}
