package Springdemo;

//import org.springframework.beans.factory.BeanFactory;
//import org.springframework.beans.factory.xml.XmlBeanFactory;
//import org.springframework.core.io.ClassPathResource;

public class Tester {
public static void main(String[] args) {
//	ClassPathResource resource=new ClassPathResource("/Springdemo/Myconfig.xml");
//	BeanFactory factory=new XmlBeanFactory(resource);
//	Bike bike=(Bike) factory.getBean("bike");
//	System.out.println(bike);
//    Car c=(Car) factory.getBean("car");
//	System.out.println(c);
//	Car c1=(Car) factory.getBean("car");
//	System.out.println(c1);
	Car car=new Car();
	car.setBrand("Audi");
	car.setColor("red");
	car.setPrice(236471);
	System.out.println(car);

	
}
}

//beanFactory is a interface because we use XmlBeanFactory
//down casting
//interface can't create object
//spring defualt singleton because same address come