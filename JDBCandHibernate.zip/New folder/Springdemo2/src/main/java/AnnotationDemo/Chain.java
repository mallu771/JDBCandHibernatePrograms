package AnnotationDemo;

import org.springframework.stereotype.Component;

@Component
public class Chain {

	@Override
	public String toString() {
		return "This is Chain";
	}

	
}
