package AnnotationDemo;

public class Dog {

}
