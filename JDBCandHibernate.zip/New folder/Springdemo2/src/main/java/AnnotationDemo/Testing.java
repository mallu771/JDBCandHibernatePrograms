package AnnotationDemo;

import javax.naming.Context;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Testing {
public static void main(String[] args) {
//	ApplicationContext applicationContext=new AnnotationConfigApplicationContext(config.class);
//	Animal animal= (Animal) applicationContext.getBean("mm");
//	System.out.println(animal);
	ApplicationContext context=new ClassPathXmlApplicationContext("abc.xml");
	Cat cat=(Cat) context.getBean("cat");
	System.out.println(cat);
	
}
}