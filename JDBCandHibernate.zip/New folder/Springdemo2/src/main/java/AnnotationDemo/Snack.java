package AnnotationDemo;

public class Snack {

}
