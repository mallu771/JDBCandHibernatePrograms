package AnnotationDemo;

import org.springframework.stereotype.Component;

@Component("mm")
public class Animal {

}
