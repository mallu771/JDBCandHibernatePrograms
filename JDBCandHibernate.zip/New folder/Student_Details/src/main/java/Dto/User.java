package Dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
//@Component
public class User {
@Id

//long id;
//String make;
//String model;
//int year;
//String rer_no;
	int id;
	String name;
	String classRoom;
//	Date DOB;
	int mark1;
	int mark2;
	int mark3;
//	double total_mark;
	
	public String getClassRoom() {
		return classRoom;
	}
	public void setClassRoom(String classRoom) {
		this.classRoom = classRoom;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
//	public Date getDOB() {
//		return DOB;
//	}
//	public void setDOB(Date dOB) {
//		DOB = dOB;
//	}
	public int getMark1() {
		return mark1;
	}
	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}
	public int getMark2() {
		return mark2;
	}
	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}
	public int getMark3() {
		return mark3;
	}
	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}
//	public double getTotal_mark() {
//		return total_mark;
//	}
//	public void setTotal_mark(double total_mark) {
//		this.total_mark = total_mark;
//	}
	public void setDOB(String parameter) {
		// TODO Auto-generated method stub
		
	}
}
//public long getId() {
//	return id;
//}
//public void setId(long id) {
//	this.id = id;
//}
//public String getMake() {
//	return make;
//}
//public void setMake(String make) {
//	this.make = make;
//}
//public String getModel() {
//	return model;
//}
//public void setModel(String model) {
//	this.model = model;
//}
//public int getYear() {
//	return year;
//}
//public void setYear(int year) {
//	this.year = year;
//}
//public String getRer_no() {
//	return rer_no;
//}
//public void setRer_no(String rer_no) {
//	this.rer_no = rer_no;
//}
//
//
//	
//}
