package Dao;


import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Repository;

import Dto.User;

//@Component
//public class Userdao
//{
//
//	@Autowired
//	UserRepository repository;
//	
//	public User save(User user) {
//		return ((Object) repository).save(user);
//	}
//
//
//	public List<User> fetchAll() {
//		return ((Object) repository).findAll();
//	}
//	
//	
//
//}

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import Dto.User;

public class Userdao  {
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	private List<User> user;
	 public void save(User user)
	 {
		 entityTransaction.begin();
		 entityManager.persist(user);
		 entityTransaction.commit();
	 }
	 public User find(int id) {
		 List<User> user=entityManager.createQuery("select x from User x where id=?1").setParameter(1, id).getResultList();
		 if(user.isEmpty())
			{
				return null;
			}
			else
				return user.get(0);

		}
	public List<User> fetchAll()
	{
		return entityManager.createQuery("select a from User a").getResultList();
	}


}
