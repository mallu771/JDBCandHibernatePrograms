package Conroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Userdao;
import Dto.User;

@WebServlet("/fetch")
public class all_fecth extends HttpServlet{

	  @Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
		  int id=Integer.parseInt(req.getParameter("id"));
			Userdao dao=new Userdao();
			User user=dao.find(id);
			
			
//			if(user==null)
//			{
//				res.getWriter().print("<h1>Invalid id</h1>");
//				req.getRequestDispatcher("login.html").include(req,res);
//			}
//			else
//			{
//				if(user.getId()==id)
//				{
					
//					List<User> list =(List<User>) dao.find(id);
					res.getWriter().print("<table border=\1\">"+"<tr>"+
		        			
		        				"<th>UserName:</th>"+
		        				"<th>Email:</th>"+
		        				"<th>Gender:</th>"+
		        				"<th>Phno:</th>"+
		        				"<th>Address:</th>"+
		        				"<th>Password:</th>"+"</tr>");
//		        			List<User> list1=(List<User>) dao.find(id);
//		        			for(User u:list)
//		        			{
		        				res.getWriter().print("<tr><th>"+user.getId()+"</th>");
		        				res.getWriter().print("<th> "+user.getName()+"</th>");
		        		        res.getWriter().print("<th>"+user.getClassRoom()+"</th>");
		        				res.getWriter().print("<th>"+user.getMark1()+"</th>");
		        				res.getWriter().print("<th> "+user.getMark2()+"</th>");
		        				res.getWriter().print("<th> "+user.getMark3()+"</th></tr>");
//		        				res.getWriter().print("...............................");
////		        			}
//
//					List<User> list =dao.fetchAll();
//					req.setAttribute("list",list);
//					req.getRequestDispatcher("fetch.jsp").forward(req, res);
//		    		
//				}
//				else{
//					
//					res.getWriter().print("<h1>Invalid id</h1>");
//
//				}
			}
	}
//}
