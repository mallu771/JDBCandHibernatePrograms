//package Conroller;
//
//import java.net.ResponseCache;
//
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseCookie;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import Dto.User;
//
//
//
//@RestController
//@RequestMapping("login")
//public class Vehicle 
//{
//	@Autowired
//	Service service;
//	
//
//	@PostMapping("saveone")
//	public ResponseCookie save(@RequestBody User user)
//	{
//		return ( (Vehicle) service).save(user);
//		
//	}
//
//		@GetMapping("fetchall")
//		public ResponseCookie fetchall()
//		{
//			return ((Object) service).fetchAll();
//		}
//}
