package Conroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Userdao;
import Dto.User;


@WebServlet("/login")
public class login extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
	
	int id=Integer.parseInt(req.getParameter("id"));
	Userdao dao=new Userdao();
	User user=dao.find(id);
	
	
	if(user==null)
	{
		res.getWriter().print("<h1>Invalid id</h1>");
		req.getRequestDispatcher("login.html").include(req,res);
	}
	else
	{
		if(user.getId()==id)
		{

			List<User> list =dao.fetchAll();
			req.setAttribute("list",list);
			req.getRequestDispatcher("Result.jsp").forward(req, res);
    		
		}
		else{
			
			res.getWriter().print("<h1>Invalid id</h1>");

		}
	}
}

}
