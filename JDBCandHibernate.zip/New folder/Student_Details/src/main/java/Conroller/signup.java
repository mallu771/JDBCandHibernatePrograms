package Conroller;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import Dao.Userdao;
import Dto.User;

@WebServlet("/signup")
public class signup extends GenericServlet{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		
		User user=new User();
		user.setId(Integer.parseInt(req.getParameter("id")));
		user.setName(req.getParameter("name"));
		user.setClassRoom(req.getParameter("Class"));
//		user.setDOB(req.getParameter("date"));
		user.setMark1(Integer.parseInt(req.getParameter("mark1")));
		user.setMark2(Integer.parseInt(req.getParameter("mark2")));
		user.setMark3(Integer.parseInt(req.getParameter("mark3")));
		Userdao dao=new Userdao();
		try {
			
			dao.save(user);
			res.getWriter().print("<h1>Student detail successfully</h1>");
			req.getRequestDispatcher("signup.html").include(req,res);
		} catch (Exception e) {
			res.getWriter().print("<h1>id already exit </h1>");
			req.getRequestDispatcher("signup.html").include(req,res);
		}
		
	}
	
	}

