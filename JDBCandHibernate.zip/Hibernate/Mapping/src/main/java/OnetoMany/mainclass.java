package OnetoMany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Persistence;

@Entity
class House
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int h_id;
	String h_name;
	String address;
	@OneToMany
	List<Room123> r;
	public int getH_id() {
		return h_id;
	}
	public void setH_id(int h_id) {
		this.h_id = h_id;
	}
	public String getH_name() {
		return h_name;
	}
	public void setH_name(String h_name) {
		this.h_name = h_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Room123> getR() {
		return r;
	}
	public void setR(List<Room123> r) {
		this.r = r;
	}
	
}
@Entity
class Room123
{
	@Id
	String room_name;

	public String getRoom_name() {
		return room_name;
	}

	public void setRoom_name(String room_name) {
		this.room_name = room_name;
	}
	
}
public class mainclass {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		House house=new House();
		house.setH_name("Amma");
		house.setAddress("katageri");
		
		Room123 rm=new Room123();
		rm.setRoom_name("workroom");
		Room123 rm1=new Room123();
		rm1.setRoom_name("kitchen");
		Room123 rm2=new Room123();
		rm2.setRoom_name("hall");
		
		List<Room123> l=new ArrayList<Room123>();
		l.add(rm);
		l.add(rm1);
		l.add(rm2);
		house.setR(l);
		entityTransaction.begin();
		entityManager.persist(house);
		entityManager.persist(rm);
		entityManager.persist(rm1);
		entityManager.persist(rm2);
		
		entityTransaction.commit();
		
	}

}
