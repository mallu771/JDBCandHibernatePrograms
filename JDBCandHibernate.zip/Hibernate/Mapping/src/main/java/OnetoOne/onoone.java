package OnetoOne;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Persistence;

@Entity
class Collector
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int c_id;
	String name;
	String loc;
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
}

@Entity
class District
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int d_id;
	String d_name;
	@OneToOne
	Collector c;
	public Collector getC() {
		return c;
	}
	public void setC(Collector c) {
		this.c = c;
	}
	public int getD_id() {
		return d_id;
	}
	public void setD_id(int d_id) {
		this.d_id = d_id;
	}
	public String getD_name() {
		return d_name;
	}
	public void setD_name(String d_name) {
		this.d_name = d_name;
	
	}
	
}
public class onoone {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	Collector collector=new Collector();
	collector.setName("Mallu");
	collector.setLoc("belagavi");
	
	District dc=new District();
	dc.setD_name("lakki");
	dc.setC(collector);
	entityTransaction.begin();
	entityManager.persist(collector);
	entityManager.persist(dc);
	entityTransaction.commit();
}
}
