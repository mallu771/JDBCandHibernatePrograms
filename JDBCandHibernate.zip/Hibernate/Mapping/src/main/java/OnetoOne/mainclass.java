package OnetoOne;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Persistence;
@Entity

class Person {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	int p_id;
	String p_name;
	String loc;
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	
}
@Entity
 class Adharcard {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	int adhar_no;
	String adhar_name;
	@OneToOne
	Person p;
	public Person getP() {
		return p;
	}
	public void setP(Person p) {
		this.p = p;
	}
	public int getAdhar_no() {
		return adhar_no;
	}
	public void setAdhar_no(int adhar_no) {
		this.adhar_no = adhar_no;
	}
	public String getAdhar_name() {
		return adhar_name;
	}
	public void setAdhar_name(String adhar_name) {
		this.adhar_name = adhar_name;
	}
	
	
}

 class mainclass {

	public static void main(String[] args) {
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Person person=new Person();
		person.setP_name("Mallu");
		person.setLoc("belagavi");
		
		Adharcard adharCard=new Adharcard();
		adharCard.setAdhar_name("Mallu1");
       adharCard.setP(person);
     
	
		entityTransaction.begin();
		entityManager.persist(person);
         entityManager.persist(adharCard);
         entityTransaction.commit();
	}
}
