package ManytoMany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Persistence;

@Entity
class Friends
{
	@Id
	String f_name;
	@ManyToMany
	List<Bottle> b;
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public List<Bottle> getB() {
		return b;
	}
	public void setB(List<Bottle> b) {
		this.b = b;
	}
	
	
}

@Entity
class Bottle
{
	@Id
	String b_name;

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	
	
}
public class Driver {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	Friends f=new Friends();
	f.setF_name("Lakki");
	Friends f1=new Friends();
	f1.setF_name("tamil");
	Friends f2=new Friends();
	f2.setF_name("mallu");
	
	Bottle bottle=new Bottle();
	bottle.setB_name("oldmonk");
	Bottle bottle1=new Bottle();
	bottle1.setB_name("bear");
	Bottle bottle2=new Bottle();
	bottle2.setB_name("kingfisher");
	
	List<Bottle> l=new ArrayList<Bottle>();
	l.add(bottle2);
	l.add(bottle1);
	l.add(bottle);
	
	f.setB(l);
	f1.setB(l);
	f2.setB(l);
	
	entityTransaction.begin();
	entityManager.persist(f2);
	entityManager.persist(f1);
	entityManager.persist(f);
	entityManager.persist(bottle);
	entityManager.persist(bottle1);
	entityManager.persist(bottle2);
	entityTransaction.commit();
	
}
}
