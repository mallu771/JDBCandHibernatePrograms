package Manytoone;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Persistence;

@Entity
class villege
{
	@Id
String name;


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


}
@Entity
class people
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
int pincode;
  String p_name;
  @ManyToOne
  villege v;
public String getP_name() {
	return p_name;
}
public void setP_name(String p_name) {
	this.p_name = p_name;
}
public villege getV() {
	return v;
}
public void setV(villege v) {
	this.v = v;
}
  
}
public class Driver {
public static void main(String[] args) {
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	villege vi=new villege();
	vi.setName("katageri");
	people p=new people();
	p.setP_name("Mallu");
	p.setV(vi);
	people p1=new people();
	p1.setP_name("lakki");
	p1.setV(vi);
	people p2=new people();
	p2.setP_name("raju");
	p2.setV(vi);
	
	entityTransaction.begin();
	entityManager.persist(vi);
	entityManager.persist(p);
	entityManager.persist(p1);
	entityManager.persist(p2);
	entityTransaction.commit();
}
}
