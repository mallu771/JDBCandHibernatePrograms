package onemanyandmanyone;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Persistence;

@Entity
class Person
{
	@Id

	String name;
	@OneToMany
	List<FaceAcc> l;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<FaceAcc> getL() {
		return l;
	}
	public void setL(List<FaceAcc> l) {
		this.l = l;
	}
	
}
@Entity
class FaceAcc
{
	@Id
	String f_name;
	@ManyToOne
	Person p;
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public Person getP() {
		return p;
	}
	public void setP(Person p) {
		this.p = p;
	}
	
}
public class Driver {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Person person=new Person();
		person.setName("mallu");
		
		FaceAcc acc=new FaceAcc();
		acc.setF_name("na12");
		FaceAcc acc1=new FaceAcc();
		acc1.setF_name("ma12");
		FaceAcc acc2=new FaceAcc();
		acc2.setF_name("kl12");
		List<FaceAcc> l=new ArrayList<FaceAcc>();
		l.add(acc2);
		l.add(acc1);
		l.add(acc);
		person.setL(l);
		acc.setP(person);
		acc1.setP(person);
		acc2.setP(person);
		
		entityTransaction.begin();
		entityManager.persist(person);
		entityManager.persist(acc);
		entityManager.persist(acc1);
		entityManager.persist(acc2);
		entityTransaction.commit();
	}
}
