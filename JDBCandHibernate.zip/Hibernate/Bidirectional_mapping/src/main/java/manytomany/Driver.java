package manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Persistence;

@Entity
class Students
{
	@Id
	String s_name;
	@ManyToMany
	List<Subjects> l;
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public List<Subjects> getL() {
		return l;
	}
	public void setL(List<Subjects> l) {
		this.l = l;
	}

	
}
@Entity
class Subjects
{
	@Id
	String sub;
	@ManyToMany
	List<Students> i;
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	public List<Students> getI() {
		return i;
	}
	public void setI(List<Students> i) {
		this.i = i;
	}
}
public class Driver {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Students st=new Students();
		st.setS_name("sachin");
		Students st1=new Students();
		st1.setS_name("lingu");
		Students st2=new Students();
		st2.setS_name("lakki");
		
		Subjects s=new Subjects();
		s.setSub("kannada");
		Subjects s1=new Subjects();
		s1.setSub("English");
		Subjects s2=new Subjects();
		s2.setSub("Telagu");
		
		List<Students> q=new ArrayList<Students>();
		q.add(st2);
		q.add(st1);
		q.add(st);
		List<Subjects> e=new ArrayList<Subjects>();
		e.add(s2);
		e.add(s1);
		e.add(s);
	  s1.setI(q);
	  s.setI(q);
	  s2.setI(q);
	  st.setL(e);
	  st1.setL(e);
	  st2.setL(e);
		st.setL(e);
		s.setI(q);
		entityTransaction.begin();
		entityManager.persist(s2);
		entityManager.persist(s1);
		entityManager.persist(s);
		entityManager.persist(st2);
		entityManager.persist(st1);
		entityManager.persist(st);
		entityTransaction.commit();
	}
}
