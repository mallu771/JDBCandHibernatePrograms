package onetoneandoneone;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Persistence;

@Entity
class Company
{
	@Id
	int ifsc;
	String name;
	@OneToOne
	Manager m;
	public int getIfsc() {
		return ifsc;
	}
	public void setIfsc(int ifsc) {
		this.ifsc = ifsc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Manager getM() {
		return m;
	}
	public void setM(Manager m) {
		this.m = m;
	}
	
}
@Entity
class Manager
{
	@Id
	String m_name;
	@OneToOne
	Company c;
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public Company getC() {
		return c;
	}
	public void setC(Company c) {
		this.c = c;
	}
	
}
public class Driver {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	Company  company=new Company();
	company.setName("SBI");
	company.setIfsc(123);
	
	Manager manager=new Manager();
	manager.setM_name("Mallu");
	manager.setC(company);
	company.setM(manager);
	
	entityTransaction.begin();
	entityManager.persist(company);
	entityManager.persist(manager);
	entityTransaction.commit();
	
}
}
