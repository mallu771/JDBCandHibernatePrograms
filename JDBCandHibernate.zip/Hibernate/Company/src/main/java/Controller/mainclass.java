package Controller;

import java.util.Scanner;

import dao.company_dao;

public class mainclass {
public static void main(String[] args) {
	
	company_dao dao=new company_dao();
	Scanner scanner=new Scanner(System.in);
	boolean flag=true;
	while(flag)
	{
		System.out.println("1.Add company details\n2.Update company details throgh id"
				+ "\n3.remove company through\n4.fetch company through id\n5.fetch all details\n6.delete all details\n7.exit");
		System.out.println("choose option");
		switch(scanner.nextInt())
		{
		case 1:
		{
			System.out.println("Enter company id");
			int c_id=scanner.nextInt();
			System.out.println("Enter company name");
			String c_name=scanner.next();
			System.out.println("Enter company salary");
			long salary=scanner.nextLong();
			System.out.println("Enter company location");
			String loc=scanner.next();
			dao.Addcompany(c_id, loc, salary, loc);
			
		}
		break;
		case 2:
		{
			System.out.println("Enter company id");
			int c_id=scanner.nextInt();
			System.out.println("Enter company name");
			String c_name=scanner.next();
			System.out.println("Enter company location");
			String loc=scanner.next();
			dao.Update(c_id, c_name,loc);
		}
		break;
		case 3:
		{
			System.out.println("Enter company id");
			int c_id=scanner.nextInt();
			dao.delete(c_id);
		}
		break;
		case 4:
		{
			System.out.println("Enter company id");
			int c_id=scanner.nextInt();
			dao.fetch(c_id);
		}
		break;
		case 5:
		{
			dao.fetchAll();
		}
		break;
		case 6:
		{
			dao.deleteAll();
		}
		break;
		case 7:
		{
			System.out.println("thank you");
			
		}
		break;
		default :
		{
			System.out.println("invalid value");
		}
		}
	}
}
}

