package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dto.company_dto;

public class company_dao {
EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
EntityManager entityManager=entityManagerFactory.createEntityManager();
EntityTransaction entityTransaction=entityManager.getTransaction();
public void Addcompany(int c_id, String c_name, long salary, String loc) {
	entityTransaction.begin();
	company_dto dto=new company_dto();
	dto.setC_id(c_id);
	dto.setC_name(c_name);
	dto.setSalary(salary);
	dto.setLoc(loc);
	entityManager.persist(dto);
	entityTransaction.commit();
	
}
public void Update(int c_id, String c_name, String loc) {
	company_dto dto=entityManager.find(company_dto.class, c_id);
	entityTransaction.begin();
	dto.setC_id(c_id);
	dto.setC_name(c_name);
	dto.setLoc(loc);
	entityManager.merge(dto);
	entityTransaction.commit();
	
}
public void delete(int c_id) {
	
	company_dto dto=entityManager.find(company_dto.class, c_id);
	if(dto!=null){
		entityTransaction.begin();
	entityManager.remove(dto);
	entityTransaction.commit();
	}
	else
		System.out.println("data not found");
}
public void fetch(int c_id) {
	
	company_dto dto=entityManager.find(company_dto.class, c_id);
	if(dto!=null){
		System.out.println(dto);
	}
	else
		System.out.println("data not found");
}
public void fetchAll() {
	Query q=entityManager.createQuery("select x from company_dto x");
	List<company_dto>  l=  q.getResultList();
	for(company_dto dto:l)
	{
		System.out.println(dto);
	}
}
public void deleteAll() {
	Query q=entityManager.createQuery("delete from company_dto");
	entityTransaction.begin();
	q.executeUpdate();
	entityTransaction.commit();
	
}

}
