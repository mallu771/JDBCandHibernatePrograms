package DTO;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Sample {
	@Id
	int cus_acc;
	String ifsc;
	String b_name;
	String branch;
	String c_name;
	public int getCus_acc() {
		return cus_acc;
	}
	public void setCus_acc(int cus_acc) {
		this.cus_acc = cus_acc;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	@Override
	public String toString() {
		return "DTO [cus_acc=" + cus_acc + ", ifsc=" + ifsc + ", b_name=" + b_name + ", branch=" + branch + ", c_name="
				+ c_name + "]";
	}
	
	
}
