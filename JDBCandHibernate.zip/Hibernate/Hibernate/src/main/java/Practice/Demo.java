package Practice;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Demo {
@Id
	int  v_no;
	String V_name;
	String model;
	String color;
	String reg_no;
	public int getV_no() {
		return v_no;
	}
	public void setV_no(int v_no) {
		this.v_no = v_no;
	}
	public String getV_name() {
		return V_name;
	}
	public void setV_name(String v_name) {
		V_name = v_name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getReg_no() {
		return reg_no;
	}
	public void setReg_no(String reg_no) {
		this.reg_no = reg_no;
	}
	@Override
	public String toString() {
		return "Demo [v_no=" + v_no + ", V_name=" + V_name + ", model=" + model + ", color=" + color + ", reg_no="
				+ reg_no + "]";
	}
	
	
}
