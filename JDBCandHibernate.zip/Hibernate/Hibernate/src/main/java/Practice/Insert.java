package Practice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Insert {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();

	Demo demo=new Demo();
	demo.setV_no(3);
	demo.setV_name("Hero");
	demo.setColor("red");
	demo.setModel("yamaha");
	demo.setReg_no("mk123");
	entityTransaction.begin();
	entityManager.persist(demo);
	entityTransaction.commit();
}
}
