package DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import DTO.Sample;

public class Demo 
{

	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();


 public void Adddetail(int cus_acc, String ifsc, String b_name, String c_name, String branch) {
	

	entityTransaction.begin();
	Sample sample=new Sample();
	sample.setCus_acc(cus_acc);
	sample.setIfsc(ifsc);
	sample.setB_name(b_name);
	sample.setC_name(c_name);
	sample.setBranch(branch);
	entityManager.persist(sample);
	entityTransaction.commit();
}


public void Update(int cus_acc, String c_name) {
   Sample s=  entityManager.find(Sample.class, cus_acc);
     if(s!=null)
     {
    	 entityTransaction.begin();
    	 s.setC_name(c_name);
    	 entityManager.merge(s);
    	 entityTransaction.commit();
     }
     else
    	 System.out.println("not updated");
	
}


public void delete(int cus_acc, String c_name) {
	
	  Sample s=  entityManager.find(Sample.class, cus_acc);
	     if(s!=null)
	     {
	    	 entityTransaction.begin();
	    	 s.setC_name(c_name);
	    	 entityManager.remove(s);
	    	 entityTransaction.commit();
	     }
	     else
	    	 System.out.println("not updated");
		
	}


public void fetch(int cus_acc) {
	Sample s=entityManager.find(Sample.class, cus_acc);
	System.out.println(s);
	
}


public void fetchAll() {
	Query q=entityManager.createQuery("select a from Sample a");
	
	 List<Sample> s=   q.getResultList();
	 for(Sample sample:s)
	 {
		 System.out.println(sample);
	 }
}


public void deleteAll() {
	
	Query q=entityManager.createQuery("delete from Sample");
	entityTransaction.begin();
	q.executeUpdate();
	entityTransaction.commit();
}


public void exit() {
	System.out.println("thank you");
	
}
}
