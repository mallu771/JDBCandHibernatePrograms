package Dynamic;

import java.util.Scanner;

import DAO.Demo;

public class Mainclass {
public static void main(String[] args) {
	Scanner scanner=new  Scanner(System.in);
	boolean flag=true;
	Demo demo=new Demo();
	while(flag)
	{
		
		System.out.println("1.Add the bank details\n 2.Update customer name\n 3.delete customer name\n 4.fetch details of customer throgth custer acc\n 5.fetch all details\n 6.delete all bank details\n 7.exit");
		
		switch(scanner.nextInt())
		{
		case 1:
		{
			System.out.println("Enter customer Acc");
			int cus_acc=scanner.nextInt();
			
			System.out.println("Enter ifsc");
			String ifsc =scanner.next();
			
			System.out.println("Enter bank name");
			String b_name=scanner.next();
			
			System.out.println("Enter customer name");
			String c_name=scanner.next();
			
			System.out.println("Enter branch");
			String branch=scanner.next();
			demo.Adddetail(cus_acc, ifsc, b_name, c_name, branch);		
		}
		break;
		case 2:
		{
			System.out.println("Enter customer Acc");
			int cus_acc=scanner.nextInt();
			System.out.println("Enter customer name");
			String c_name=scanner.next();
			demo.Update(cus_acc, c_name);
		}
		break;
		
		case 3:
		{
			System.out.println("Enter customer Acc");
			int cus_acc=scanner.nextInt();
			System.out.println("Enter customer name");
			String c_name=scanner.next();
			demo.delete(cus_acc, c_name);
		}
		break;
		case 4:
		{
			System.out.println("Enter customer Acc");
			int cus_acc=scanner.nextInt();
			demo.fetch(cus_acc);
		}
		break;
		case 5:
		{
			demo.fetchAll();
		}
		break;
		case 6:
		{
			demo.deleteAll();
		}
		break;
		case 7:
		{
			demo.exit();
		}
		break;
		default :
		{
			System.out.println("Invalid value");
		}
		}
		
	}
}
}
