package exce_handling_123;

public class null_exce {

	   public static void main(String[] args) 
	    {
		   
		System.out.println("*****Main Start********");
		null_pointer_ex s1=null;
		try{
		System.out.println(s1.hashCode());
		}
		catch(NullPointerException e)
		{
		System.out.println("handled....");
	    }
		System.out.println("****Main End*****");
	}
	}


