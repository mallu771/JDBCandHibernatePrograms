package exce_handling_123;

public class null_pointer_ex {

}
