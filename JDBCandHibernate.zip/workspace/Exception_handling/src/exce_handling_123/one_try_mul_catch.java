package exce_handling_123;

public class one_try_mul_catch {
public static void main(String[] args) {
	System.out.println("***Stsrt main");
	int[] arr={1,2,34,4};
	try{
	int n=arr[9];
	}
	catch(ArrayIndexOutOfBoundsException e){
		System.out.println("cought");
	}
	catch(ArithmeticException e)
	{
		System.out.println("handled");
	}
	System.out.println("***Stsrt main");

}
}
