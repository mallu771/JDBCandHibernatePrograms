package exce_handling_123;

public class cannot_re_address_CTE {
public static void main(String[] args) {
	try{
	int n=1/0;
	}
	catch(Exception e)
	{
		System.out.println("cought..");
	}
//	catch(ArithmeticException e)
//	{
//		System.out.println("handled...");
//	}
}
}
