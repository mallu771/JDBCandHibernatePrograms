package exce_handling_123;

import java.util.Arrays;

public class arra_length {
public static void main(String[] args) {
	int[] arr={2,4,6,1};
	int count=0;
	Arrays.sort(arr);
	try{
	for(int i=0;;i++)
	{
		System.out.print(arr[i]+" ");
		count++;
	}
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.print("--->"+count);
	}
}
}
