package exce_handling_123;

public class printstacktrace {
static void disp3()
		{
			int i=1/0;
		}
static void disp2()
{
	disp3();
}
static void disp1()
{
	disp2();
	
}
public static void main(String[] args) {
	try{
		disp1();
	}
	catch(ArithmeticException e)
	{
		e.printStackTrace();
		
	}
}
}
