package exce_handling_123;

public class catch_within_try_catch {
public static void main(String[] args) {
	try
	{
		int n=1/0;
	}
	catch(ArithmeticException e)
	{
//		System.out.println("caugth///");
		int[] arr={1,3,5,6,7};
		try{
			int m=arr[8];
		}
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.println("handeled....");
		}
	}
	
}
}
