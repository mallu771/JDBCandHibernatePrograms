package exce_handling_123;
public class cheked_exception {

	static void submit() throws MarriageException
	{
		int age=16;
		if(age>=21)
		{
			System.out.println("married that girl");
		}
		else
			throw new MarriageException("invalid age");
	}
	public static void main(String[] args) {
		try{
		     submit();
		}
		catch(MarriageException e)
		{
			System.out.println(e.getMessage());
		}
}
}
class MarriageException extends Exception
{
	String msg;
	MarriageException(String msg)
	{
		this.msg=msg;
	}
	public String getMessage(){
		return msg;
	}
}
