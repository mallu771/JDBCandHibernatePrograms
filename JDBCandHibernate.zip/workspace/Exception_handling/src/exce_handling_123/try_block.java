package exce_handling_123;

public class try_block {
public static void main(String[] args) {
	try
	{
		int a=1/0;
	}
	finally
	{
		System.out.println("finallly blooked...");
	}
}
}
