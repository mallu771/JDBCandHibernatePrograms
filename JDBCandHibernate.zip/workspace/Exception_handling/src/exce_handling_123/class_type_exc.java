package exce_handling_123;
import java.util.List;
import java.util.ArrayList;
import java.util.Vector;
public class class_type_exc {
public static void main(String[] args) {
	System.out.println("***start main*****");
	List l1=new ArrayList();
	try{
	Vector v1=(Vector)l1;
	}
	catch(ClassCastException e)
	{
		System.out.println("handled....");
	}
	System.out.println("***end main*****");
}
}
