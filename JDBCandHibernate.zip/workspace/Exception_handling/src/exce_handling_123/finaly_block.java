package exce_handling_123;

public class finaly_block {
public static void main(String[] args) {
	try
	{
		int a=1/0;
	}
	catch(ArithmeticException e)
	{
		System.out.println("handled...");
	}
	finally
	{
		System.out.println("finally blocked...");
	}
}
}
