package onetomany;
import java.util.*;

import javax.persistence.*;

@Entity
class student
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	@OneToMany
	List<InstaAcc> l;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<InstaAcc> getL() {
		return l;
	}
	public void setL(List<InstaAcc> l) {
		this.l = l;
	}
	
}
@Entity
class InstaAcc
{
	@Id
	String Iname;

	public String getIname() {
		return Iname;
	}

	public void setIname(String iname) {
		Iname = iname;
	}
}
public class Driver {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		student s=new student();
		s.setName("deepa_pa");
		
		InstaAcc a=new InstaAcc();
		a.setIname("mallu12");
		InstaAcc a1=new InstaAcc();
		a1.setIname("shree2");
		InstaAcc a2=new InstaAcc();
		a2.setIname("headche2");
		List<InstaAcc> i=new ArrayList<InstaAcc>();
		i.add(a);
		i.add(a1);
		i.add(a2);
		s.setL(i);
		entityTransaction.begin();
		entityManager.persist(a);
		entityManager.persist(a1);
		entityManager.persist(a2);
		entityManager.persist(s);
		entityTransaction.commit();
			
	}

}
