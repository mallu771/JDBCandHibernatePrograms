package onetoone;

import javax.persistence.*;

@Entity
class Pancard
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int Pid;
	String Pnumber;
	String Address;
	public int getPid() {
		return Pid;
	}
	public void setPid(int pid) {
		Pid = pid;
	}
	public String getPnumber() {
		return Pnumber;
	}
	public void setPnumber(String pnumber) {
		Pnumber = pnumber;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	
}
@Entity
 class Person
 {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 int id;
	 String name;
	 @OneToOne
	 Pancard pancard;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Pancard getPancard() {
		return pancard;
	}
	public void setPancard(Pancard pancard) {
		this.pancard = pancard;
	}
	 
 }
public class Driver {
	public static void main(String[] args) {
		
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	Pancard pancard=new Pancard();
	pancard.setAddress("Gulbarga");
	pancard.setPnumber("123j2ww");
	
	
	Person person=new Person();
	person.setName("Mallu");
	person.setPancard(pancard);
	
	entityTransaction.begin();
	entityManager.persist(person);
	entityManager.persist(pancard);
	entityTransaction.commit();
	}
}
