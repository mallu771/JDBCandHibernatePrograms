package manytoone;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Persistence;

@Entity
class Train
{
	@Id
	String t_name;

	public String getT_name() {
		return t_name;
	}

	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	
	
}
@Entity
class Passenger
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	@ManyToOne
	Train train;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Train getTrain() {
		return train;
	}
	public void setTrain(Train train) {
		this.train = train;
	}
	
}
public class Driver {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Train train=new Train();
		train.setT_name("belagavi Express");
		
		Passenger passenger=new Passenger();
		passenger.setName("Mallu");
		passenger.setTrain(train);
		
		Passenger passenger2=new Passenger();
		passenger2.setName("Deepa_p");
		passenger2.setTrain(train);
		
		Passenger passenger3=new Passenger();
		passenger3.setName("headache");
		passenger3.setTrain(train);
		entityTransaction.begin();
		entityManager.persist(train);
		entityManager.persist(passenger3);
		entityManager.persist(passenger2);
		entityManager.persist(passenger);
		entityTransaction.commit();
		
	}

}
