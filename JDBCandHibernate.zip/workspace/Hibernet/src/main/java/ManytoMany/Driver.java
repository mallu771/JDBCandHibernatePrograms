package ManytoMany;

import java.util.*;
import javax.persistence.*;
@Entity
class Traveller
{
@Id
	String tname;
	@ManyToMany
	List<TouristPlace> l;
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public List<TouristPlace> getL() {
		return l;
	}
	public void setL(List<TouristPlace> l) {
		this.l = l;
	}
	
}
@Entity
class TouristPlace
{
	@Id
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
public class Driver {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		TouristPlace place=new TouristPlace();
		place.setName("belagavi");
		TouristPlace place2=new TouristPlace();
		place2.setName("gulbarga");
		TouristPlace  place3=new TouristPlace();
		place3.setName("rayachur");
		
	List<TouristPlace> p=new ArrayList<TouristPlace>();
	p.add(place);
	p.add(place2);
	p.add(place3);
	
	Traveller traveller=new Traveller();
	traveller.setTname("DeepaP");
	traveller.setL(p);
	Traveller traveller2=new Traveller();
	traveller2.setTname("Mallu");
	traveller2.setL(p);
	Traveller traveller3=new Traveller();
	traveller3.setTname("Shree");
	traveller3.setL(p);
	entityTransaction.begin();
	entityManager.persist(place);
	entityManager.persist(place3);
	entityManager.persist(place2);
	entityManager.persist(traveller3);
	entityManager.persist(traveller2);
	entityManager.persist(traveller);
	entityTransaction.commit();
	
	}

}
