package controller;

import java.util.Scanner;

import Dao.sample;

public class mainclass {
public static void main(String[] args) {
	Scanner scanner=new  Scanner(System.in);
	sample sample= new sample();
	boolean flag=true;
	while(flag)
	{
		System.out.println("1.add emp\n 2.fetch emp\n 3. remove\n 4.update\n 5.fetch all\n 6.remove all\n 7.exit");
		switch(scanner.nextInt())
		{
		case 1:
		{
			System.out.println("Enter emp id");
			int id=scanner.nextInt();
			System.out.println("Enter emp name");
			String name=scanner.next();
			System.out.println("Enter emp salary");
			double sal=scanner.nextDouble();
			System.out.println("Enter emp job role");
			String job_role=scanner.next();
			sample.AddEmp(id, name, sal, job_role);
		}
		break;
		case 2:
		{
			System.out.println("Enter emp id");
			int id=scanner.nextInt();
			sample.fetchEmp(id);
		}
		break;
		case 3:
		{
			System.out.println("Enter emp id");
			int id=scanner.nextInt();
			sample.removeEmp(id);
		}
		break;
		case 4:
		{
			System.out.println("Enter emp id");
			int id=scanner.nextInt();
			System.out.println("Eneter emp sal");
			double sal=scanner.nextDouble();
			sample.updateempSal(id, sal);
		}
		break;
		case 5:
		{
			sample.fetchAll();
		}
		break;
		case 6:
		{
			sample.deleteAll();
		}
		break;
		case 7:
		{
			flag=false;
			System.out.println("thank you");
		}
		break;
		default:
		{
			System.out.println("invalid options");
			break;
		}
		}
	}
}
}
