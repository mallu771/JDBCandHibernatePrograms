package Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dto.Demo1;

public class sample {
EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
EntityManager entityManager=entityManagerFactory.createEntityManager();
EntityTransaction entityTransaction=entityManager.getTransaction();
public void AddEmp(int id, String name, double sal,String job_role)
{
	entityTransaction.begin();
	Demo1 demo=new Demo1();
	demo.setEmp_id(id);
	demo.setName(name);
	demo.setSalary(sal);
	demo.setJob_role(job_role);
	entityManager.persist(demo);
	entityTransaction.commit();
}
public void fetchEmp(int id){
	Demo1 e=entityManager.find(Demo1.class, id);
	if(e!=null)
		System.out.println(e);
	else
		System.out.println("data not found");
}
public void removeEmp(int id)
{
	Demo1 e=entityManager.find(Demo1.class, id);
	if(e!=null)
	{
		entityTransaction.begin();
		entityManager.remove(e);
		entityTransaction.commit();
	}
	else
		System.out.println("data not found");
}
public void updateempSal(int id ,double sal)
{
	Demo1 e=entityManager.find(Demo1.class, id);
	if(e!=null)
	{
		entityTransaction.begin();
		e.setSalary(sal);
		entityManager.merge(e);
		entityTransaction.commit();
	}
	else
		System.out.println("data not found");
}

public void fetchAll()
{
	Query e=entityManager.createQuery("select b from Demo1 b");
	List<Demo1> w=e.getResultList();
	for(Demo1 f: w)
		System.out.println(f);
}
public void deleteAll()
{
	Query e=entityManager.createQuery("delete from Demo1");
	entityTransaction.begin();
	e.executeUpdate();
	entityTransaction.commit();
}
}
