package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Demo1 {
	@Id
private int emp_id;
	@Column(nullable=false)
private String name;
private double salary;
@Column(nullable=false)
private String job_role;
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}

public void setName(String name) {
	this.name = name;
}

public void setSalary(double salary) {
	this.salary = salary;
}
public void setJob_role(String job_role) {
	this.job_role = job_role;
}
@Override
public String toString() {
	return "Demo1 [emp_id=" + emp_id + ", name=" + name + ", salary=" + salary + ", job_role=" + job_role
			+ " ]";
}
}
