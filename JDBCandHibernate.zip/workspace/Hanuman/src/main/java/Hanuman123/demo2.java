package Hanuman123;

public class demo2 {

}
