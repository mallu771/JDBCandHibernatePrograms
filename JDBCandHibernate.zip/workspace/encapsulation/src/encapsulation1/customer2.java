package encapsulation1;


class instagram
{
	private String pwd="mgb@123";
    public String getpwd()
    {
    	return pwd;
    }
    public void setpwd(String pwd)
    {
    	this.pwd=pwd;
    }
}
 class customer2
{
	public static void main(String[] args)
	{
		instagram i1=new instagram();
			String m=i1.getpwd();
			System.out.println("old password:"+m);
		i1.setpwd("mallu143");
		System.out.println("new password:"+i1.getpwd());
	}
}


