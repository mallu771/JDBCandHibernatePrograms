package encapsulation1;

class whatsapp
{
	private int pwd=2342;
    public int getpwd()
    {
    	return pwd;
    }
    public void setpwd(int pwd)
    {
    	this.pwd=pwd;
    }
}
 class customer3
{
	public static void main(String[] args)
	{
		whatsapp w1=new whatsapp();
			int m=w1.getpwd();
			System.out.println("old password:"+m);
		w1.setpwd(3346);
		System.out.println("new password:"+w1.getpwd());
	}
}

