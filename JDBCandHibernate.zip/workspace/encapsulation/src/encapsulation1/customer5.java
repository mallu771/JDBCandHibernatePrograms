package encapsulation1;
class laptop
{
	private String pwd="chinari";
    public String getpwd()
    {
    	return pwd;
    }
    public void setpwd(String pwd)
    {
    	this.pwd=pwd;
    }
}
 class customer5
{
	public static void main(String[] args)
	{
		laptop l1=new laptop();
			String m=l1.getpwd();
			System.out.println("old password:"+m);
		l1.setpwd("mallu143");
		System.out.println("new password:"+l1.getpwd());
	}
}


