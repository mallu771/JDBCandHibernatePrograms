package encapsulation1;

class ICICI_bank
{
	private String pwd="mallu123";
    public String getpwd()
    {
    	return pwd;
    }
    public void setpwd(String pwd)
    {
    	this.pwd=pwd;
    }
}
 class customer1
{
	public static void main(String[] args)
	{
		ICICI_bank i1=new ICICI_bank();
			String m=i1.getpwd();
			System.out.println("old password:"+m);
		i1.setpwd("mgb123");
		System.out.println("new password:"+i1.getpwd());
	}
}

