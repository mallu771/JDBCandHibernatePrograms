package encapsulation1;

class phone_pay
{
	private int pwd=9352;
    public int getpwd()
    {
    	return pwd;
    }
    public void setpwd(int pwd)
    {
    	this.pwd=pwd;
    }
}
 class customer4
{
	public static void main(String[] args)
	{
		phone_pay p1=new phone_pay();
			int m=p1.getpwd();
			System.out.println("old password:"+m);
		p1.setpwd(3346);
		System.out.println("new password:"+p1.getpwd());
	}
}


