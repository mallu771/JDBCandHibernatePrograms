package set_pgm;
import java.util.HashSet;
public class hashset 
{
public static void main(String[] args) 
{
	HashSet h1=new HashSet();
	h1.add(10);
	h1.add('A');
	h1.add("hee");
	h1.add(10);
	System.out.println(h1);
}
}
