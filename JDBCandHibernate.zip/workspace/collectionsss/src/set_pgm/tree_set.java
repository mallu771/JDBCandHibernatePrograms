package set_pgm;

import java.util.TreeSet;

public class tree_set {
	public static void main(String[] args) 
	{
		TreeSet h1=new TreeSet();
		h1.add(10);
		h1.add(23);
		h1.add(50);
		h1.add(30);
		h1.add(40);
		h1.add(9);
		System.out.println(h1);
	}
}
