package set_pgm;

import java.util.LinkedHashSet;

public class linkedhash {
	public static void main(String[] args) 
	{
		LinkedHashSet h1=new LinkedHashSet();
		h1.add(10);
		h1.add('A');
		h1.add("hee");
		h1.add(10);
		h1.add(true);
		h1.add('A');
		System.out.println(h1);
	}
}
