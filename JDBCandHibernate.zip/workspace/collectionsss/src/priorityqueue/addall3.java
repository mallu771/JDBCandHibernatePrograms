package priorityqueue;

public class addall3 {

}
