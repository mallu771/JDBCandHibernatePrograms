package priorityqueue;
import java.util.PriorityQueue;
public class add1 {
	
	   public static void main(String[] args){
		   PriorityQueue l1=new PriorityQueue();
		l1.add(10);
		l1.add(20);
		l1.add(40);
		l1.add(50);
		l1.add(30);
		System.out.println(l1);
	}
	}


