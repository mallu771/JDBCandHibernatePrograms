package collectionsss123;
import java.util.ArrayList;
public class retainsall {
					public static void main(String[] args)
							{
						
							ArrayList l1=new ArrayList();
							l1.add(10);
							l1.add(20.20);
							l1.add(50);
							l1.add(60);
							l1.add(true);
							
							ArrayList l2=new ArrayList();
							l2.add(30);
							l2.add(40);
							l2.add(50);
							l2.add(60);
							l1.retainAll(l2);
							System.out.println(l1);
							
						}
						
				}





