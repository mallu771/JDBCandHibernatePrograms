package collectionsss123;
import java.util.ArrayList;
public class size_get {
		public static void main(String[] args)
									{
								
									ArrayList l1=new ArrayList();
									l1.add("tumkura");
									l1.add("gulberga");
									l1.add("belagavi");
									l1.add("raichur");
									l1.add("yadageri");
									for(int i=0;i<l1.size();i++)
									{
										Object o1=l1.get(i);
									

									     System.out.println(o1);
									}
								}
								
						}

