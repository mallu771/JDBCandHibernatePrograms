package collectionsss123;
import java.util.ArrayList;
public class remove12 {
			public static void main(String[] args)
					{
				
					ArrayList l1=new ArrayList();
					l1.add(10);
					l1.add(20.20);
					l1.add("hi");
					l1.add('A');
					l1.add(true);
					l1.remove(0);
					
					System.out.println(l1);
				}
				
		}

