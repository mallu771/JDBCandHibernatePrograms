package collectionsss123;
import java.util.ArrayList;
public class addall2 {
		public static void main(String[] args)
				{
			
				ArrayList l1=new ArrayList();
				l1.add(10);
				l1.add(20.20);
				l1.add("hi");
				l1.add('A');
				l1.add(true);
				ArrayList l2=new ArrayList();
				l2.add(20);
				l2.add("hello");
				l1.addAll(2,l2);
				System.out.println(l1);
			}
			
	}


