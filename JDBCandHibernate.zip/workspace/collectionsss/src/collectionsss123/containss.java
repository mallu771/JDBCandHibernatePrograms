package collectionsss123;
import java.util.ArrayList;
public class containss {

						public static void main(String[] args)
								{
							
								ArrayList l1=new ArrayList();
								l1.add("tumkura");
								l1.add("gulberga");
								l1.add("belagavi");
								l1.add("raichur");
								l1.add("yadageri");
								if(l1.contains("tumkura"))
								{
									System.out.println("its contains tumkura ");
								}
								else
								     System.out.println("not contains");
								
							}
							
					}


