package Map_pgm;

import java.util.LinkedHashMap;

public class linkedhash {
	public static void main(String[] args) {
		LinkedHashMap<String,Integer> h1=new LinkedHashMap<String,Integer>();
	
	h1.put("Mallu", 100);
	h1.put("Manju", 101);
	h1.put("Raju", 102);
	h1.put("Lukey", 103);
	System.out.println(h1);
}
}
