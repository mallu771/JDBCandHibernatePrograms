package Map_pgm;
import java.util.HashMap;
public class hashmap {
public static void main(String[] args) {
	HashMap<String,Integer> h1=new HashMap<String,Integer>();
	
	h1.put("Mallu", 100);
	h1.put("Manju", 101);
	h1.put("Raju", 102);
	h1.put("Lukey", 103);
	System.out.println(h1);
}
}
