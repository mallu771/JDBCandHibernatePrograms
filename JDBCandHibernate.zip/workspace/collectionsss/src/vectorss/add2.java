package vectorss;
import java.util.Vector;
public class add2 {

		public static void main(String[] args){
			Vector l1=new Vector();
			l1.add(10);
			l1.add(20.20);
			l1.add("hi");
			l1.add('A');
			l1.add(true);
			l1.add(2,"hell0");
			System.out.println(l1);
		}
		}


