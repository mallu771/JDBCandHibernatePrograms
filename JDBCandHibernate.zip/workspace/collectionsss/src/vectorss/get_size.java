package vectorss;
import java.util.Vector;
public class get_size {
		
				public static void main(String[] args){

					Vector v2=new Vector();
									v2.add(30);
									v2.add(40);
									v2.add("hello");
									v2.add("hi");
					for(int i=0;i<v2.size();i++){
						Object o1=v2.get(i);
										System.out.println(o1);
									}
									}

}
