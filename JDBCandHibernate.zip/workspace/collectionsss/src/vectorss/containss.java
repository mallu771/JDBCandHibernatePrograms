package vectorss;
import java.util.Vector;
public class containss {
			
					public static void main(String[] args){

						Vector v2=new Vector();
										v2.add("tumkura");
										v2.add(40);
										v2.add("gulbarga");
										v2.add("belagavi");
					if(v2.contains("tumkura"))
					{
						System.out.println("its contains");
										}
					else
						System.out.println("its not contains");
										}

	}


