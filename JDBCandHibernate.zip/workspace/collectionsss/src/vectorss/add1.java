package vectorss;
import java.util.Vector;
public class add1 {

	public static void main(String[] args){
		Vector l1=new Vector();
		l1.add(10);
		l1.add(20.20);
		l1.add("hi");
		l1.add('A');
		l1.add(true);
		System.out.println(l1);
	}
	}
