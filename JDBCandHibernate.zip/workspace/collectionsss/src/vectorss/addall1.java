package vectorss;
import java.util.Vector;
public class addall1 {
		public static void main(String[] args){
			Vector l1=new Vector();
			l1.add(10);
					l1.add(20.20);
					l1.add("hi");
					l1.add('A');
					l1.add(true);
				Vector v2=new Vector();
				v2.add(30);
				v2.add(40);
				v2.add("hello");
				l1.addAll(1,v2);
					System.out.println(l1);
				}
				}

