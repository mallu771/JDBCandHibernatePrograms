package vectorss;
import java.util.Vector;
public class addall21 {
	
		public static void main(String[] args){

			Vector v2=new Vector();
							v2.add(30);
							v2.add(40);
							v2.add("hello");
							v2.add("hi");
			Vector v3=new Vector();
			v3.add(10);
			v3.add(20);
			v3.add(30);
			v3.add(40);
				v2.removeAll(v3);
								System.out.println(v2);
							}
							}



