package vectorss;
import java.util.Vector;
public class remove1 {
public static void main(String[] args){

					Vector v2=new Vector();
					v2.add(30);
					v2.add(40);
					v2.add("hello");
					v2.remove(1);
						System.out.println(v2);
					}
					}



