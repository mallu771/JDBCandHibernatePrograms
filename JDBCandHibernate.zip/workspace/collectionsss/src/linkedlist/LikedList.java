package linkedlist;
import java.util.LinkedList;
public  class LikedList {
	public static void main(String[] args) {
		LinkedList l1=new LinkedList();
		l1.add(10);
		l1.add(10.99);
		l1.add("hi");
		l1.add(10);
		LinkedList l2=new LinkedList();
		l1.add(20);
		l1.add(12.99);
		l1.add("hloo");
		l1.add(19);
		System.out.println(l1);
		System.out.println("peeking-->"+l1.peek());
		System.out.println(l1);
		System.out.println("polling-->"+l1.poll());
		System.out.println(l1);
		
	}
}
