package filepgm;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class IOExecption extends Exception {
		public static void main(String[] args) throws  IOException  {
			InputStreamReader i1=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(i1);
			System.out.println("Enter the value");
			String a=br.readLine();
			int x=Integer.parseInt(a);
			System.out.println(x);
		}
	}


