package filepgm;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
public class buffer_dyna {
public static void main(String[] args) throws IOException  {
	InputStreamReader inputStreamReader=new InputStreamReader(System.in);
	BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
	System.out.println("enrte value");
	String s1=bufferedReader.readLine();
	int s2=Integer.parseInt(s1);
	System.out.println(s2);
}
}
