package filepgm;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class buffer_reader {

	public static void main(String[] args) throws IOException {
		File f1=new File("C://Users//Abhishek//Desktop//friend_resume//mgb//ma.text");
	FileReader fileReader=new FileReader(f1);
	BufferedReader bufferedReader=new BufferedReader(fileReader);
	String s1=bufferedReader.readLine();
	while(s1!=null){
	System.out.println(s1);
//	s1=bufferedReader.readLine();
	break;
	}
}
}
