package filepgm;
import java.io.File;
import java.io.IOException;
public class file_2 {
	public static void main(String[] args) throws IOException {
		File f1=new File("C://Users//Abhishek//Desktop//mgb//ma.text");
		if(f1.createNewFile())
		{
			System.out.println("created file");
		}
		else
			System.out.println("not created file");
			
}
}
