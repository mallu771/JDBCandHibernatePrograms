package filepgm;
import java.io.File;
public class file_1 {
public static void main(String[] args) {
	File f1=new File("C://Users//Abhishek//Desktop//mgb");
	if(f1.mkdirs())
		System.out.println("there is folder");
	else
		System.out.println("alreay is there");
	if(f1.exists())
		System.out.println("folder exits");
	else
		System.out.println(" folder not exits");
//	if(f1.delete())
//		System.out.println("folder is deleted");
//	else
//		System.out.println("folder is not deleted");
}
}
