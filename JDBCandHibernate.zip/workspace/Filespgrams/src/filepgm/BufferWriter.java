package filepgm;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;

public class BufferWriter {

	public static void main(String[] args) throws IOException {
		File f1=new File("C://Users//Abhishek//Desktop//friend_resume//mgb//ma.text");
		FileWriter fileWriter=new FileWriter(f1);
		BufferedWriter bufferedWriter=new BufferedWriter(fileWriter);
		bufferedWriter.write("sfs");
//		bufferedWriter.newLine();
		bufferedWriter.write("hjgjkd");
//		bufferedWriter.newLine();
		bufferedWriter.write("ksjdlajdl");
//		bufferedWriter.newLine();
		bufferedWriter.flush();
        System.out.println("data sffs");
}

	
	}

