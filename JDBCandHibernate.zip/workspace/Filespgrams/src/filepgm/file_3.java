package filepgm;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class file_3 {
public static void main(String[] args) throws IOException {
	File f1=new File("C://Users//Abhishek//Desktop//mgb//ma.text");
	FileWriter fw=new FileWriter(f1);
	fw.write("hii");
	fw.write("hello");
	fw.flush();
	System.out.println("data is written");
}
}
