package filepgm;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class file_append {
	public static void main(String[] args) throws IOException {
		File f1=new File("C://Users//Abhishek//Desktop//mgb//ma.text");
		FileWriter fw =new FileWriter(f1,true);
		fw.write("hellohiicool");
		fw.flush();
		System.out.println("data is written");

}
}
