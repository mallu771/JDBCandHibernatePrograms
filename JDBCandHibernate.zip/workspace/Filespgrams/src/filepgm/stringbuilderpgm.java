package filepgm;

public class stringbuilderpgm {
public static void main(String[] args) {
	String str="i am java";
	StringBuilder ans=new StringBuilder();
	str = str.replace(" ", "@40");
	ans.append(str);
	System.out.println(ans);
}
}
