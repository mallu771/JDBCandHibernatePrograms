package pattern_A_Z;

       class D extends Thread
      {
    	   public void run(){
    		   try{
    			   Thread.sleep(1000);
    			   int n=5;
		for (int i = 1; i <=n; i++) {
			for (int j = 1; j <=n; j++) {
				if(i==1||j==1||j==n||i==n)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
      }
    		   catch (Exception e) {
				e.printStackTrace();
			}}
      }
       
 class E  extends Thread{
	  public void run(){
		  try{
			   Thread.sleep(4000);
			   int n=5;
		for (int i = 1; i <=n; i++) {
			for (int j = 1; j <=n; j++) {
				if(j==1||i==1||i==5||i==n/2+1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		}
		  catch (Exception e) {
			e.printStackTrace();
		}
	}
 }
class E1 extends Thread{
	public void run(){
		 try{
			   Thread.sleep(6000);
			   int n=5;
		for (int i = 1; i <=n; i++) {
			for (int j = 1; j <=n; j++) {
				if(j==1||i==1||i==5||i==n/2+1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		}
		 catch (Exception e) {
			e.printStackTrace();
		}
	}}
class P extends Thread{
	public void run(){
		 try{
			   Thread.sleep(8000);
			   int n=5;
	for (int i = 1; i <=n; i++) {
		for(int j=1;j<=n;j++){
			if(j==1||i==1||(j==n&&i<=n/2+1)||i==5/2+1)
			{
				System.out.print("*");
			}
			else
				System.out.print(" ");
		}
		System.out.println();
	}
}
		 catch (Exception e) {
			e.printStackTrace();
		}
}
}
     class A extends Thread
     {
    	 public void run(){
    		 try{
  			   Thread.sleep(10000);
  			   int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(j==1||i==1||j==n||i==n/2+1)
						{
				
				System.out.print("*");
				}
				else
				System.out.print(" ");
		}
			System.out.println();		
		}
    	 }	catch (Exception e) {
			e.printStackTrace();
		}
		}}
public class Name {
public static void main(String[] args) {
	D d=new D();
	Thread thread=new Thread(d);
	thread.start();
	E e=new E();
	Thread thread1=new Thread(e);
	thread1.start();
	E1 e1=new E1();
	Thread thread2=new Thread(e1);
	thread2.start();
	P p=new P();
	Thread thread3=new Thread(p);
	thread3.start();
	A a=new A();
	Thread thread4=new Thread(a);
	thread4.start();
}
}
