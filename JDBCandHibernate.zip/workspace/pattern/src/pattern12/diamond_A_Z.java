package pattern12;
import java.util.Scanner;
public class diamond_A_Z {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		int star=1;
		char nn='A';
		int space=n/2;
		for (int i = 1; i <=n; i++) {
			for (int j = 1; j <=space; j++) {
				System.out.print(" ");
			}
			for (int k = 1; k <=star; k++) {
				System.out.print(nn++);
			}
		
			System.out.println();
			if(i<=n/2)
			{
				star=star+2;
				space--;
			}
			else{
				star=star-2;
			space++;
		}
	}
	}
	}
