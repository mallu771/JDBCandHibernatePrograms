package array_fact;

public class arr_fact
{
  public static void main(String[] args)
  {
	    int[] arr={5,1,4,3,2};
	    for(int i=0;i<arr.length;i++)
	    {
	    	 for(int j=0;j<arr.length-1;j++)
	    	 {
	    		 
	    		 if(arr[j]>arr[j+1])
	    		 {
	    			int temp=arr[j];
	    			arr[j]=arr[j+1];
	    			arr[j+1]=temp;
	    		 }
	    	 }
	    }
	    for(int i=0;i<arr.length;i++)
	    {
	    	
	    	int fact=1;
	    	for(int j=arr[i];j>=1;j--)
	    	{
	    		fact=fact*j;
	    	}
	    	System.out.println(fact);
	    }
	   
  }
}
	 
	

