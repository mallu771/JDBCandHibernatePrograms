package array_fact;

public class Sidd1 {
	public static void main(String[] args) {
		String str = "jspider";
		char[] ch = str.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			int k=0;
			for (int j = 0; j <= i; j++) {
				System.out.print(ch[k]);
				k++;
			}
			System.out.println();
		}
	}
}
