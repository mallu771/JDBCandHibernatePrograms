package array_fact;
import java.util.Arrays;
public class arr_fact1 {

	  public static void main(String[] args)
	  {
		    int[]arr={3,2,5,4,1};
		    
		    Arrays.sort(arr);
		    for(int i=0;i<arr.length;i++)
		    {
		    	
		    	int fact=1;
		    	for(int j=arr[i];j>=1;j--)
		    	{
		    		fact=fact*j;
		    	}
		    	System.out.println(fact);
		    }
		   
	  }
	}
		 
