package mallu123.mallu123;
import java.sql.*;
import com.mysql.cj.jdbc.PreparedStatementWrapper;
public class dynamic_databse {
public static void main(String[] args) throws Exception 
{
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","ROOT");
	Statement statement=connection.createStatement();
	statement.execute("create database anna");
	connection.close();
	
}
}