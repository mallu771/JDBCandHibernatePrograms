package com.mysql.cj.jdbc;

public class PreparedStatementWrapper {

}
