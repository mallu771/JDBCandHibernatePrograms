package Charr;

public class Samplee {
public static void main(String[] args) {
	String str1="i love india";
	String[]str2=str1.split(" ");
	String rev="";
	for (int i= str2.length-1;i>=0; i--) {
		rev=rev+str2[i]+(" ");
		
	}
System.out.println(rev);
}
}
