package programs;
import java.util.Scanner;
public class hello 
{
public static void main(String[] args) 
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter some value");
	int a=sc.nextInt();
	double d=sc.nextDouble();
	sc.nextLine();
	 String str=sc.nextLine();
System.out.println("*****************");
	System.out.println(str);
	System.out.println(d);
     System.out.println(a);
}
 }
	


 