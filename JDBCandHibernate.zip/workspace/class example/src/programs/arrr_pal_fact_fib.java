package programs;

public class arrr_pal_fact_fib {

		public static void main(String[] args)
		{
			int[] arr={8134,25652,78987,6381,2675,13531};
			for(int i=0;i<arr.length;i++)
			{
				int sum=0;
				int sum1=0;
				int sum2=0;
				int rev=0;
				int m=arr[i];
				int fact=1;
				while(arr[i]!=0)
				{
					int rem=arr[i]%10;
					rev=(rev*10)+rem;
					arr[i]=arr[i]/10;
					
				}
				
				
			if(rev==m)
			{
			
				while(rev!=0)
				{
					int rem=rev%10;
					sum=sum+rem;
					rev=rev/10;
				}
			
			
			
			while(sum!=0)
			{
				int rem=sum%10;
				sum1=sum1+rem;
				sum=sum/10;
			}
			
			while(sum1!=0)
			{
				int rem=sum1%10;
				sum2=sum2+rem;
				sum1=sum1/10;
			}
			
			for(int j=sum2;j>=1;j--)
			{
				fact=fact*j;
			}
			
			System.out.println(sum2+" ->Factorial of number is: "+fact);
			
			}
			
			else 
			{

				int sum3=0;
				while(rev!=0)
				{
					int rem=rev%10;
					sum3=sum3+rem;
					rev =rev/10;
				}
			
			int sum4=0;
				
				while(sum3!=0)
				{
					int rem=sum3%10;
					sum4=sum4+rem;
					sum3=sum3/10;
				
				
				}
				System.out.println("fibonacy series: "+sum4);
				int fib1=0;
				int fib2=1;
				int fib3;
			
				System.out.print(fib1+" "+fib2+" ");
				for(int k=1;k<=sum4;k++)
				{
				
					fib3=fib1+fib2;
					System.out.print(" "+fib3); 
					fib1=fib2;
					fib2=fib3;
				}
				
				
			}
			System.out.println("\n"+"***************************");
			}
			
			
			}
		}
	

