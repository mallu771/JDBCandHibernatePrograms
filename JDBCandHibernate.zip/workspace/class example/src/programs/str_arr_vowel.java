package programs;
import java.util.Arrays;
public class str_arr_vowel {
		public static void main(String[] args)
		{
			
			String s="mallikarjun";
			str_arr(s);
		}
		static void str_arr(String s)
		{   
			int vow=0;
			char[] ch=s.toCharArray();
			Arrays.sort(ch);
		for(int i=0;i<s.length();i++)
		{
			
			if(ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
			{
				vow++;
			}
		}
			System.out.println(vow);
		}
	}


