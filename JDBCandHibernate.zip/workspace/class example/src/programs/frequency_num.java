package programs;

import java.util.Scanner;

public class frequency_num {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		int s=sc.nextInt();
		int n[]=new int[s];
		for (int i = 0; i < n.length; i++) {
			n[i]=sc.nextInt();
		}
		int dup=-1;
		int fr[]=new int[n.length];
		for (int i = 0; i < n.length; i++) {
			int count=1;
			for (int j = i+1; j < n.length; j++) {
				if(n[i]==(n[j]))
				{
					count++;
					fr[j]=dup;
				}
			}
			if(fr[i]!=dup)
			{
				fr[i]=count;
			}
			
		}
		for (int i = 0; i < n.length; i++) {
			if(fr[i]!=dup)
				System.out.println(n[i]+" -->"+fr[i]);
			
		}
}
}
