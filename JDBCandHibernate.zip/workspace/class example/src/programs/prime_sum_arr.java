package programs;

public class prime_sum_arr {
	public static void main(String[] args) {
		int[] a={10,82,1,23,15,47};
		int sum=0;
		
		for (int i = 0; i < a.length; i++) {
			int count=0;
			for (int j = 2; j < a[i]; j++)
			{
				if (a[i]%j==0)
				{
                      count++;
					}
			}
		
		if(count==0){
			sum=sum+a[i];
	
		}
		
	}
		System.out.println(sum);
	}
}

