package programs;
import java.util.Scanner;
public class happy_mallu {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetr number...");
		int n=sc.nextInt();
		int copy=n;
		int sum;
		while(n>9)
		{
			sum=0;
			do{
			int rem=n%10;
			sum=sum+(rem*rem);
			n=n/10;
			}while(n!=0);
			n=sum;
		}
		if(n==1 || n==7)
		{
			System.out.println(copy+":happy number");
		}
		else
			System.out.println(copy+":Not happy number");
	}
}
