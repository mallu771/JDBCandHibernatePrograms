package programs;

public class frequency_pgm_l {
public static void main(String[] args) {
	String str="abcacg";
	char ch[]=str.toCharArray();
	
	int fr[]=new int[ch.length];
	int dup=-1;
	for(int i=0;i<ch.length;i++)
	{
		 int count=1;
	   for (int j = i+1; j < ch.length; j++) {
		          if(ch[i]==ch[j])
		          {
		        	  count++;
		        	  fr[j]=dup;
		          }
	}
	   
	   if(fr[i]!=dup)
	   {
		   fr[i]=count;
	   }
	}
	for(int i=0;i<ch.length;i++)
	{
		if(fr[i]!=dup)
		System.out.println(ch[i]+"---> "+fr[i]);
	}
}
}
