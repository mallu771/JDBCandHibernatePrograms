package programs;

public class testcase1 {
public static void main(String[] args) {
	int[] arr={1,2,3,8,6,13};
	int sum=0;
	int sum1=0;
	for (int i = 0; i < arr.length; i++) {
		if(arr[i]%2==1)
			sum=sum+arr[i];
		if(arr[i]%2==0)
			sum1=sum1+arr[i];
	}
	System.out.println(sum+(sum-sum1));
}
}
