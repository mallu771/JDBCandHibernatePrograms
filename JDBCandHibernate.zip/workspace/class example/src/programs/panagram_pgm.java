package programs;

import java.util.Arrays;

public class panagram_pgm
{
public static void main(String[] args) 
{
	String str="the quick brown fox jumps over the lazy dog lazy dog";
	char[] ch=str.toCharArray();
	int fr[]=new int[ch.length];
	int count = 1;
	for (int i = 0; i < ch.length; i++) 
	{
		
		for (int j = i+1; j < ch.length; j++) 
		{
			if(ch[i]==ch[j])
			{
				count++;
			
				fr[j]=-1;
				break;
		}
	}
	
	if(fr[i]!=-1)
		{
		fr[i]=count;
		}
	
	}
int ucount=0;
	
for (int i = 0; i < fr.length; i++) {
	if(fr[i]>1)
		ucount++;
			
	}
if(ucount>=26)
	System.out.println("panagram");
	else
	System.out.println("Not panagram");
	}
}

