package programs;
import java.util.Scanner;
public class array_mix_dyn {
  
	public static void main(String[] args){
		  Scanner sc=new Scanner(System.in);
		  System.out.print("Enter arrays");
		  int size=sc.nextInt();
		  int[] arr=new int[size];
		  for(int i=0;i<arr.length;i++){
				 arr[i]=sc.nextInt();
			 }
		 array_par(arr);
	 }
	 static void array_par(int[] arr){
		 
		 int max=arr[0];
		 for(int i=1;i<=arr.length-1;i++){
			 
			 if(arr[i]>max){
				 max=arr[i];
			 }
		 }
		 System.out.println(max);
		 
}
}