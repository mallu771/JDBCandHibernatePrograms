package programs;
import java.util.Scanner;
public class sum_two {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter numbers");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println(numberss(n1,n2));
	}
	static boolean numberss(int n1, int n2)
	{
		int sum=n1+n2;
		
		if((n1==10 || n2==10 || sum==10))
		{
			return true;
		}
		else{
			return false;
		}
	}
}
