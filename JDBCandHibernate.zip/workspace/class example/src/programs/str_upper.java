package programs;
import java.util.Scanner;
public class str_upper {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Eneter string");
		String str=sc.nextLine();
		String res="";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			int x=(int) ch;
			res=res+(char)(x+32);
		}
		System.out.println(res);
	}
}
