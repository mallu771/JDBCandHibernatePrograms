package programs;

public class arr_palin {
	public static void main(String[] args)
	{
		int[] arr={121,146,721,171,23632};
		for(int i=0;i<arr.length;i++)
		{
			int m=arr[i];
			int rev=0;
		  while(arr[i]!=0)
		  {
			  int rem=arr[i]%10;
			  rev=(rev*10)+rem;
			arr[i]=arr[i]/10;  
		  }
		  if(m==rev)
		  {
			  System.out.println(rev+":palindrome");
		  }
		  else
			  System.out.println(rev+":Not palindrome");
		}
	}
}
