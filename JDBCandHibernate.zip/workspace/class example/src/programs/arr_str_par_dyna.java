package programs;
import java.util.Arrays;
import java.util.Scanner;
public class arr_str_par_dyna {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter string");
		String s=sc.nextLine();
		str_arr(s);
	}
	static void str_arr(String s)
	{
		char[] ch=s.toCharArray();
		Arrays.sort(ch);
		System.out.println(ch);
	}
}
