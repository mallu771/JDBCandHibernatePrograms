package programs;
import java.util.Scanner;
public class arr_pal_dyn 
{
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter number");
			int size=sc.nextInt();
			int[] arr=new int[size];
			System.out.println("Eneter arrys");
			for(int i=0;i<arr.length;i++)
			{
			      arr[i]=sc.nextInt();
			}
			arr_pali(arr);
		}
		static void arr_pali(int[] arr)
		{
			
			for(int i=0;i<arr.length;i++)
			{
				int m=arr[i];
				int rev=0;
			  while(arr[i]!=0)
			  {
				  int rem=arr[i]%10;
				  rev=(rev*10)+rem;
				arr[i]=arr[i]/10;  
			  }
			  if(m==rev)
			  {
				  System.out.println(rev+":palindrome");
			  }
			  else
				  System.out.println(rev+":Not palindrome");
			}
		}
	}


