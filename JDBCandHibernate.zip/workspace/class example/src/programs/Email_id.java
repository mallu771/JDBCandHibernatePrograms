package programs;

import java.util.Scanner;
public class Email_id {
	public static void main(String[] args){ 
	Scanner sc=new Scanner(System.in);
	System.out.println("Eneter string");
	String str=sc.nextLine();
	String res="";
	for(int i=0;i<str.length();i++)
	{
		char ch=str.charAt(i);
		if((ch>='A'&& ch<='Z')&&(ch!=' '))
		{

		int x=(int) ch;
		res=res+(char)(x+32);
	}
		else 
			res=res+ch;
}
	System.out.println(res);
}
}