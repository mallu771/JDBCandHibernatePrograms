package programs;
import java.util.Scanner;
public class xylem_phloem {
	public static void main(String[] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number");
	
	int n=sc.nextInt();
    int fsum=0;
    int lsum=0;
    int copy=n;
    while(n!=0)
    {
    	//1223->1+3=4,2+2=4,  4==4
    	if(copy==n||n<=9)
    	{
    		fsum=fsum+n%10;
    	}
    	else
    		lsum=lsum+n%10;
    	
    	n=n/10;
    }
    if(fsum==lsum)
    {
    	System.out.println("it xylem number");
    }
    else 
    	System.out.println("it is phloem number");
	}
}
