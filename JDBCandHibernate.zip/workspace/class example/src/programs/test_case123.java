package programs;

import java.util.Arrays;

public class test_case123 {
public static void main(String[] args) {
	int[] arr={1,2,3,8,6,13};
	int sum=0;
	
	for (int i = 0; i < arr.length; i++) {
		int count=0;
		for (int j = 2; j <arr[i]; j++) 
		{
			if(arr[i]%j==0)
			{
				count++;
				break;
			}
		}
		
		if(count==0){
		    sum=sum+arr[i];
		}
		
	}
	System.out.println(sum);}
}
