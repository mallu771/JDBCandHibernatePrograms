package programs;
import java.util.Scanner;
import java.util.Arrays;
public class anagram_meth_count {
	

			public static void main(String[] args)
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter Strings");
				String str1=sc.nextLine();
				String str2=sc.nextLine();
				new angram_meth_dyna().anagram_method(str1,str2);
			}
			 void anagram_method(String str1,String str2)
			{
				int count=0;
			if(str1.length()==str2.length())
			{
				char[] ch1=str1.toCharArray();
				char[] ch2=str2.toCharArray();
				Arrays.sort(ch1);
				Arrays.sort(ch2);
			for(int i=0;i<ch2.length;i++)
			{
				if(ch1[i]!=ch2[i])
		{
			count++;
			break;
		}
			}
			
			if(count==0)
			{
				System.out.println("Anagram");
			}
			else{
				System.out.println("not Anagram");
			}
			}
			else
				System.out.println("String not matched");
			}
		}
