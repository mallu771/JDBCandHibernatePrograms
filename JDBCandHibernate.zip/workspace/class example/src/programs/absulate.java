package programs;
import java.util.Scanner;
public class absulate {
	
			public static void main(String[] args)
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter numbers");
				int n1=sc.nextInt();
				System.out.println(abdiff(n1));
			}
		   static int abdiff(int n1)
		   {
			   if(n1<=21)
			   {
				   return 21-n1;
			   }
			   else if(n1>21)
				   return (n1-21)*2;
			   return n1;
		   }
		}




