package programs;

public class mmmmmm {
	
		public static void main(String[] args) {
			int[] a={11,12,13,22,25};
			int sum=0;
			for (int i = 0; i < a.length; i++) {
				int count=0;
				for (int j = 2; j < a[i]; j++)
				{
					if (a[i]%j==0)
					{
	                      count++;
						}
				}
			
			if(count==0){
				sum=sum+a[i];
		
			}
			
		}
			System.out.println(sum);
		}
	}

