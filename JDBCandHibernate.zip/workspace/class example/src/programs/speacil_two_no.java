package programs;
import java.util.Scanner;
public class speacil_two_no {
	public static void main(String[] args)
	{
		//sum=d1+d2+(d1*d2)  29
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		
		int d1=n%10;
		int d2=n/10;
		int sum=(d1+d2)+(d1*d2);
		if(sum==n)
		{
			System.out.println(sum+":it 2-digit number");
		}
		else 
			System.out.println(sum+":it not 2-digit number");
	}
}
