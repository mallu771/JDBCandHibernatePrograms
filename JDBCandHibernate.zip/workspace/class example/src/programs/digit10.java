package programs;

public class digit10 {
	public static void main(String[] args)
	{
		String str="1234567892";
		char[] ch=str.toCharArray();
	for(int i=0;i<str.length();i++)
	{
		
		int n=str.charAt(i);
		ch[i]++;
	}
	}
}
