package programs;
import java.util.Scanner;
public class count_pass_8 {
	  
 		public static void main(String[] args){ 
 			
 		  Scanner sc=new Scanner(System.in);
 		  System.out.println("Enter String..");
 		  String str=sc.nextLine();
 			  int u_count=0;
 			  int l_count=0;
 			  int n_count=0;
 			  int s_count=0;
 		
 			if(str.length()>=8)
 			 {
				for(int i=0;i<str.length();i++)
				{
					 
					char ch=str.charAt(i);
					if((ch>='a'&& ch<='z'))
					{

					l_count++;
				}
					else if((ch>='A'&& ch<='Z'))
					{

					u_count++;
				}
					else if((ch>='0'&& ch<='9'))
					{

					n_count++;
				}
					else
						s_count++;
				
			}
 			 }
 			if(u_count>=1 && l_count>=1 && n_count>=1 && s_count>=1 && str.endsWith("#"))
 			{
 				System.out.println("valid=====");
 			}
 			else
 				System.out.println("not valid----");
		
		}
		}



