package programs;

public class count_text {
	public static void main(String[] args)
	{
		String str="Edu evening batch question kotra send madu logic ok";
		int cout=1;
		
		for(int i=0;i<str.length();i++)
		{
		char	ch= str.charAt(i);
			
		if(ch==' ')
		{
	       cout++;
		}
		}
		
		if(cout%2==0)
		{
			System.out.println(cout);
		}
		else
		{
			System.out.println(str.length());
		}
	}
	}


