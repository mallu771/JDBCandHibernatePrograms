package programs;

public class mid_arr {
	private static final char[] String = null;

	public static void main(String[] args) {
		int[] arr={11,12,13,22,25};
		/*int f_index=0;
		
	    int l_index=a.length-1;
		 int mid=(f_index+l_index)/2;
			
		System.out.println(a[mid]);*/
		/*int mid=(arr[arr.length/2]);
		System.out.println(mid);*/
	System.out.println(arr[arr.length/2+1]+" "+arr[arr.length/2]);
	
	}		
}  


