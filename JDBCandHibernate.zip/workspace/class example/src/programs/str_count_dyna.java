package programs;
import java.util.Scanner;
public class str_count_dyna {
	      public static void main(String[] args)
	      {
	    	  Scanner sc =new Scanner(System.in);
	    	  System.out.println("Enter String");
	    	  String str=sc.nextLine();
	    	 
	    	  char[] ch=str.toCharArray();
	    	  int count=0;
	    	for(int i=0;i<str.length();i++)
	    	{
	    		if(ch[i]!=' '){
	    		count++;
	    	}
	    	}
	    	System.out.println(count);
	      }
	}


