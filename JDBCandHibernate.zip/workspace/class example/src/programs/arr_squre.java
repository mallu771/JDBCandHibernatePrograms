package programs;

import java.util.Arrays;

public class arr_squre {
public static void main(String[] args) {
	int[] arr={4,5,3,2};
	Arrays.sort(arr);
	int a=0;
	for (int i = 0; i < arr.length; i++) {
		a=(int) Math.pow(arr[i], 2);
		System.out.println(a);
	}
	
}
}
