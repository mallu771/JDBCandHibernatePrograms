package programs;
import java.util.Scanner;
public class count_arr_method 
   {
	
		public static void main(String[] args)
		{
			Scanner sc =new Scanner(System.in);
			System.out.println("Enter String");
			
		   String str=sc.nextLine();
			new count_arr_method().count_arr(str);
			
			
		}
		 void count_arr(String str)
		{
			
			int[] arr=new int[122];
			for(int i=0;i<str.length();i++)
			{
				char ch=str.charAt(i);
				arr[ch]++;
			}
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i]!=0)
				{
					System.out.println((char)i+" "+arr[i]);
				}
			}
		}
	}


