package programs;

public class str_count {
      public static void main(String[] args)
      {
    	  String str="mallikarjun baja";
    	 
    	  char[] ch=str.toCharArray();
    	  int count=0;
    	for(int i=0;i<str.length();i++)
    	{
    		if(ch[i]!=' '){
    		count++;
    	}
    	}
    	System.out.println(count);
      }
}
