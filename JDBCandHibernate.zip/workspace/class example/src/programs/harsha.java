package programs;

import java.util.Scanner;

public class harsha {
	public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter row");
	int n1=sc.nextInt();
	
	System.out.println("Enter column");
	int n2=sc.nextInt();
			
	int[][] arr1=new int[n1][n2];
	
	for(int k1=0;k1<arr1.length;k1++)
	{	for(int j=0;j<arr1[k1].length;j++){
		arr1[k1][j]=sc.nextInt();
	}
	}
	int sum=0;
	for(int k11=0;k11<arr1.length;k11++)
	{	
		
		int i=0;
		for(int j=0;j<arr1[k11].length;j++){
		
			
		if(arr1[i]==arr1[j])
		{
		sum+=arr1[k11][j];
	   }
		i++;
		}
	}
	 
	System.out.println(sum);
}
}
