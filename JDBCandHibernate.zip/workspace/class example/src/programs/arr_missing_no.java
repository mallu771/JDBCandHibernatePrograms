package programs;

public class arr_missing_no {
	public static void main(String[] args)
    {
        int[] arr = { 1, 2, 3,4, 5,6,8,9,10 };
        int n = arr.length;
        missing_num(arr, n);
    }
	
	    static void missing_num(int[] arr, int n)
	    {
	        int sum = ((n + 1) * (n + 2)) / 2;
	        for (int i = 0; i < n; i++){
	        	
	        
	            sum =sum- arr[i];
	        }
	      System.out.println(sum);
	    }
	 
	    
	    
	}

