package programs;

public class count_witout_arr {
	      public static void main(String[] args)
	      {
	    	  String str="mallikarjun bajantri";
	    	 
	    	  int count=0;
	    	for(int i=0;i<str.length();i++)
	    	{
	    		if(str.charAt(i)!=' '){
	    		count++;
	    	}
	    	}
	    	System.out.println(count);
	      }
	}


