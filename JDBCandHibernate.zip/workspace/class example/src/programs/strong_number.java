package programs;
import java.util.Scanner;
public class strong_number {
	
   public static void main(String[] args){
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter number");
	 int n=sc.nextInt();
	 strong_num(n);
   }
   static void strong_num(int n){
	   int m=n;
	   int sum=0;
	   while(n!=0){
	   int rem=n%10;
	   int fact=1;
	  
	  
	  for(int i=rem;i>=1;i--){
		  fact=fact*i;
	  }
	  sum=sum+fact;
	  n=n/10;
   }

      if(sum==m){
	   System.out.println(m+" is a Strong number");
	   
   }
   else{
	   System.out.println(m+" is a Not Strong number");
}
      }
}

