package programs;

public class fib_3_num {
 public static void main(String[] args)
 {

	 demo1456.fib_mm();
 }
}
class demo1456
{
	static void fib_mm()
	{
	 int fib1=0;
	 int fib2=1;
	int fib311;
	 System.out.print(fib1+" "+fib2);
	 for(int i=1;i<=10;i++)
	 {
		fib311=fib1+fib2;
		fib1=fib2;
		fib2=fib311;
		System.out.print(" "+fib311);
	 }
	 
 }
}
