package programs;

import java.util.Scanner;
public class rev_str_rturn {
	public static void main(String[] args) {
					Scanner sc=new Scanner(System.in);
					System.out.println("Eneter String");
					String str=sc.nextLine();
					System.out.println(str_rev_num(str));
					
				}
				

				static String str_rev_num(String str)
				{
					String[] str1=str.split(" ");
					String rev="";
					for(int i=str1.length-1;i>=0;i--)
					{
						rev=rev+str1[i]+" ";
				}
					return rev;
		}


		
	}

