package programs;
import java.util.Scanner; 
public class weekday {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter booleans");
		boolean n1=sc.nextBoolean();
		boolean n2=sc.nextBoolean();
		System.out.println(sleepIn(n1,n2));
	}
   static boolean sleepIn(boolean week,boolean vacation)
   {
	   if(week==false||vacation==true)
	   {
		   return true;
	   }
	   else
		   return false;
   }
}
