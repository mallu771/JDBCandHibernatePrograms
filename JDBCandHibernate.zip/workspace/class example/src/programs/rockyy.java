package programs;
import java.util.Scanner;
public class rockyy
{
   public static void main(String[] args) 
   {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter string...");
	  String str=sc.nextLine();
	  String copy=""; 
	  for( int i=str.length()-1;i>=0;i--)
	  {
          copy=copy+str.charAt(i);
	  }
	  if(str.equals(copy))
	  {
		  System.out.println("string is palindrome");
	  }
	  else
	  {
		  System.out.println("string is not an palindrome");
	  }
		  
}

}
