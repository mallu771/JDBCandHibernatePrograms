package programs;
import java.util.Scanner;
public class armstrong {
	public static void main(String[] args)
	{
		
   Scanner sc =new Scanner(System.in);
   System.out.println("Enter number");
   int n=sc.nextInt();
   sample x= new sample();
     x.armstrong_num(n);
}
}
class sample{
	void armstrong_num(int n){
		int sum=0;
		int m=n;
		while(n!=0){
			int rem=n%10;
			sum+=(Math.pow(rem, 3));
			n=n/10;
		}
	if(sum==m)
	{
		System.out.println(sum+":armstrong number");
	}
	else
		System.out.println(sum+": not armstrong number");
	}
}

