package programs;
import java.util.Scanner;
public class arr_miss_u {
	public static void main(String[] args)
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter size");
       int n=sc.nextInt();
       int[] arr=new int[n];
       System.out.println("Enter arrrys");
       for(int i=0;i<arr.length;i++)
       {
    	   arr[i]=sc.nextInt();
       }
     
	miss_u(arr);
       }
	static void miss_u(int[] arr)
	{
		int sum=0;
       for(int j=1;j<=arr.length+1;j++)
       {
    	   sum=sum+j;
       }
     for(int j=0;j<arr.length;j++)
      {
    	  sum=sum-arr[j];
      }
   System.out.println(sum);
    }


}
