package programs;

import java.util.Arrays;

public class testcase_6 {
public static void main(String[] args) {
	char arr[]={'Z','Q','R','A','P'};
	Arrays.sort(arr);
	int res[]=new int[arr.length];
	for (int i = 0; i < res.length; i++) {
		res[i]=(int)(arr[i]-64);
	}
	System.out.println(Arrays.toString(res));
}
}
