package programs;

import java.util.Arrays;

public class split_sub {
public static void main(String[] args) {
	String str="jonny jonney yes pappa eating sugar no pappa";
	String sub="pappa";
	String ch[]=str.split(sub);
	System.out.println(Arrays.toString(ch));
	if(str.startsWith(sub)==false&&str.endsWith(sub)==false)
	{
		System.out.println(ch.length-1);
	}
	else if(str.startsWith(sub)==true && str.endsWith(sub)==true)
	{
		System.out.println(ch.length);
	}
	if(str.startsWith(sub)==true || str.endsWith(sub)==true)
	{
		System.out.println(ch.length);
	}
}
}
