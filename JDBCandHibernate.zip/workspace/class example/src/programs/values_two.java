package programs;
import java.util.Scanner;
public class values_two {

		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter numbers");
			int n1=sc.nextInt();
			int n2=sc.nextInt();
			System.out.println(numberss(n1,n2));
			
		}
		static int numberss(int n1, int n2)
		{
			
			if(n1==n2)
			{
				return (n1+n2)*2;
				
			}
			else{
			  return n1+n2;
			}
		}
	}


