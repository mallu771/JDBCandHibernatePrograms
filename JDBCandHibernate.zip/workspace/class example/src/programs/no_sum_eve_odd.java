package programs;

public class no_sum_eve_odd {
	public static void maod(String[] args)
	{
		int n=24;
		int sum=0;
	while(n!=0)
	{
		int rem=n%10;
		sum=sum+rem;
		n=n/10;
	}
	for(int i=1;i<sum;i++)
	{
		int sum1=0;
	if(sum%i==0)
		
	{		
		sum1=sum1+i;
		int fact=1;
			for(int j=sum1;j>=1;j--){
				
			
				
				fact=fact*i;
			}
			
			System.out.println(fact);
	}
	}
		}
	}

