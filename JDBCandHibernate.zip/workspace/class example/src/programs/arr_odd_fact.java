package programs;

public class arr_odd_fact {
	public static void main(String[] args)
	{
       int[] arr={326,742,821,654,213};
       
       for(int i=0;i<arr.length;i++)
       {
    	   int sum=0;
       while(arr[i]!=0)
       {
    	   int rem=arr[i]%10;
    	   sum=sum+rem;
    	   arr[i]=arr[i]/10;
        
       }
      
       if(sum%2==1)
       {
    	   int fact=1; 
        for(int j=sum;j>=1;j--)
        
          {
        	  fact=fact*j;
          }
        System.out.println(fact);
        }
       
       }
       }
	}

