package programs;
import java.util.Scanner;
public class sec_max_arr {
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter size:");
			int size=sc.nextInt();
			System.out.print("Enter arrays:");
			int[] arr=new int[size];
			
			for(int i=0;i<arr.length;i++)
			{
				arr[i]=sc.nextInt();
			}
		arr_sort(arr);
		}
		static void arr_sort(int[] arr)
		{
			for(int i=0;i<arr.length;i++)
			{
				for(int j=0;j<arr.length-1;j++)
				{
					if(arr[j]>arr[j+1])
					{
						int temp=arr[j];
						arr[j]=arr[j+1];
						arr[j+1]=temp;
					}
				}
				
				
			}
			
			System.out.print(arr[arr.length-2]+" ");	
		}
	}


