package programs;
import java.util.Arrays;
public class test_case3 {
public static void main(String[] args) {
	int[] arr={5,9,3,2,8,7};
	Arrays.sort(arr);
	int res[]=new int[arr.length];
	int x=0;
	for (int i = 0; i < res.length; i++) {
		if (arr[i]%2==1) {
	      res[x]=arr[i];
	      x++;
		}
	}
		for (int i = 0; i< res.length; i++) {
			
			if (arr[i]%2==0) {
			      res[x]=arr[i];
			      x++;
				}
	
	}
		System.out.print(Arrays.toString(res));
	}
	
}

