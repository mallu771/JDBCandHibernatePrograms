package programs;

public class array_test_2 {
	public static void main(String[] args) {
		int[] arr={7,9,10,8,16};
		int sum=0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]%2==0)
				sum=sum+arr[i];
		}
		System.out.println(sum-1);
	}
}
