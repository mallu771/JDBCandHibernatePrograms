package programs;

public class arr_miss_nu {
	
		public static void main(String[] args)
	    {
	        int[] arr = { 1, 2, 3,4, 5,6,8,9,10 };
	        int sum=0;
	        for(int i=1;i<=10;i++)
	        {
	        	
	        	sum=sum+i;
	        }
	   for(int j=0;j<arr.length;j++)
	   {
		     sum =sum- arr[j];
		      
		    } 
	   System.out.println(sum);
	    }

}
