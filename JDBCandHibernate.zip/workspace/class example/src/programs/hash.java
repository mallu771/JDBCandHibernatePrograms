package programs;
import java.util.HashMap;
public class hash {
	public static void main(String[] args) {
		HashMap<String,Integer> l=new HashMap<String,Integer>();
		l.put("ma", 90);
		System.out.println(l);
	}


}
