package programs;
public class mid_sum_arr_3 {
		public static void main(String[] args) {
			int[] a={10,82,1,23,15,47};

			int f_index=0;
		    int l_index=a.length-1;
			
			  int mid=(f_index+l_index)/2;
			  int mid1=mid-1;
			  int mid2=mid+1;
			  int sum=a[mid1]+a[mid]+a[mid2];
		
			System.out.println(sum);

		}		
	}


