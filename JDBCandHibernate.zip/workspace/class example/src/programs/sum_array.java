package programs;
import java.util.Arrays;
public class sum_array {
	public static void main(String[] args)
	{
		int[] arr={3,5,6,1};
		int sum=0;
		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		System.out.println(sum);
	}
	
	
}
