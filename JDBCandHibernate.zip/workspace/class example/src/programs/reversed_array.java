package programs;

public class reversed_array {
	public static void main(String[] args)
	{
		int[] arr={1,2,3,4,5};
		System.out.println();
		int[] brr=new int[arr.length];
		for(int i=0,j=arr.length-1;i<arr.length){
			
		}
	}
}
