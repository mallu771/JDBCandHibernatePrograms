package programs;
import java.util.Scanner;
public class xylem {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String n=sc.nextLine();
		xylem12(n);
	}
	static void xylem12(String n)
	{
		String str1="";
		String str2="";
		char[] ch=n.toCharArray();
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]=='#')
			{
				str1=str1+ch[i];
			}
			else
				str2=str2+ch[i];
		}
		System.out.println(str1+str2);
}
}
