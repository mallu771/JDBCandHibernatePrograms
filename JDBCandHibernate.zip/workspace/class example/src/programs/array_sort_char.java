package programs;
import java.util.Scanner;
import java.util.Arrays;
public class array_sort_char {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("enter number");
		int size=sc.nextInt();
		System.out.print("enter arrays");
		int[] arr=new int[size];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}

	arr_char(arr);
	}
	static void arr_char(int[] arr)
	{
	    Arrays.sort(arr);
	for(int i=0;i<arr.length;i++)
	{
		int n1=65-1;
		int n2=arr[i];

		char ch=(char)((char)n1+(n2));
		System.out.println(ch);
	}
	
	}
}
