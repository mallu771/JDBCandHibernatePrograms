package programs;
import java.util.Scanner;
public class monkey {
	
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter booleans");
			boolean n1=sc.nextBoolean();
			boolean n2=sc.nextBoolean();
			System.out.println(twomonkeys(n1,n2));
		}
	   static boolean twomonkeys(boolean asmile,boolean bsmile)
	   {
		   if(asmile==false||bsmile==true)
		   {
			   return true;
		   }
		   else
			   return false;
	   }
	}


