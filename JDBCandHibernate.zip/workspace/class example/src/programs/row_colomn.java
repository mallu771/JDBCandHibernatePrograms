package programs;
import java.util.Scanner;
import java.util.Arrays;
public class row_colomn {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row ");
		int n1=sc.nextInt();
		
		int[] arr1=new int[n1];
	
		
		System.out.println("Enter column");
		int n2=sc.nextInt();
		int[] arr2=new int[n2];
		
		for(int k=0;k<arr1.length;k++)
		{
			arr1[k]=sc.nextInt();
		}
		for(int h=0;h<arr2.length;h++)
		{
			arr2[h]=sc.nextInt();
		}
		sum_rc(arr1,arr2);
	}
	static void sum_rc(int[] arr1,int[] arr2)
	{
		int sum=0;
		
		for(int i=0;i<arr1.length;i++)
		{
			
			for(int j=0;j<arr2.length;j++)
			{ 
				int k=0;
				if(arr1[k]==arr2[j])
				{
					sum+=arr2[j]+arr1[i];
					
				}
				else
					System.out.println("n");
				
			}
		}
	}
}
