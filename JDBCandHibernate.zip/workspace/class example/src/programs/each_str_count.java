package programs;

public class each_str_count {
	
		      public static void main(String[] args)
		      {
		    	  String str="hoga beda hudugi nanna bittu";
		    	 char[] ch=str.toCharArray();
		    	
		    	for(int i=0;i<ch .length;i++)
		    	{
		    		String st1="";
		    	while(i<ch.length && ch[i]!=' '){
		    	
		    		st1=st1+ch[i]; 
		    		i++;
		    	}
		    		if(st1.length()>0)
		    		{
		    			
		    			System.out.println(st1+" "+st1.length()+" ");
		    	}
		    	
		    	
		      }
		}}




