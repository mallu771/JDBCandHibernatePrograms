package programs;
import java.util.Scanner;
public class mac_harries {
	public static void main(String[] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number of nth boxs");
	int n1=sc.nextInt();
	willington_city(n1);
	}
	static void willington_city(int n1)
	{
		System.out.println("xth number of fruits");
		int f1=0;
		int f2=1;
		int f3;
		System.out.print(f1+" "+f2);
		for(int i=0;i<=n1;i++)
		{
			f3=f1+f2;
			System.out.print(" "+f3);
			f1=f2;
			f2=f3;
		}
		
	}
}
