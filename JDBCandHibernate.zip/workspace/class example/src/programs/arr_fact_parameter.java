package programs;

public class arr_fact_parameter {

}
