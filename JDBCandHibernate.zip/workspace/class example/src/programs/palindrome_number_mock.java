package programs;

public class palindrome_number_mock {
	public static void main(String[] args){
  int n=122;
  int rev=0;
  int m=n;
  while(n!=0)
  {
	  int rem=n%10;
	  rev=(rev*10)+rem;
	  n=n/10;
  }
  if(rev==m)
  {
  System.out.println("palindrome");
}
  else
  {
	  System.out.println("not palindrome");
  }
  }
}
