package programs;
import java.util.Scanner;
public class parot {
	 public static void main(String[] args)
	 {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter number and booleans");
		 int n1=sc.nextInt();
		 boolean n2=sc.nextBoolean();
		 
		System.out.println( hour(n1,n2));
	 }
	
	 static boolean hour(int n1, boolean n2)
	 {
		 boolean flag=true;
		 for(int i=0;i<=23;i++)
		 {
			 if((n1<7 || n1>20)&&(n2==flag)){
				 
				 return true;
			 }
			 else 
			 {
				 return false;
			 }
		 }
		 return n2;
		
		 }
	 }

