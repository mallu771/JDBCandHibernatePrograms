package programs;

public class happy {
public static void main(String[] args)
{
	int n=28;
	int res=n;
	while(res!=1&&res!=4)
	{
		res=happynum(res);
	}
	if(res==1)
	{
		System.out.println("happy number");
	}
	else
		System.out.println("Not happy number");
}
public static int happynum(int n)
{
	
	int sum=0;
	while(n!=0)
	{
		int rem=n%10;
		sum=sum+(rem*rem);
		n=n/10;
	}
	return sum;
	
}
}
