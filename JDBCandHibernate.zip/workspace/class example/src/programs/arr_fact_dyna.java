package programs;
import java.util.Scanner;
public class arr_fact_dyna {
	
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter numbers");
			int size=sc.nextInt();
			System.out.println("Enter arrays");
			int[] arr=new int[size];
			for(int i=0;i<arr.length;i++)
			{
				arr[i]=sc.nextInt();
			}
			arr_count(arr);
		
	}
		static void arr_count(int[] arr)
		{
			int count=0;
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i]>10 && arr[i]<20)
				{
					count++;
				}
				
			}
			System.out.println(count);
		}
	}


