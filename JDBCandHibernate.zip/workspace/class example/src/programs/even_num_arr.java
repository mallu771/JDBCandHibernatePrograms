package programs;

public class even_num_arr {
	public static void main(String[] args)
	{
	   int 	arr[]={10,82,1,23,15,47};
		int count=0;
		int ocount=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]%2==0)
			{
				count++;
				
			}
			else
				ocount++;
			
		}
		System.out.println(count+":even array");
		System.out.println("*********************");
		System.out.println(ocount+":odd array");
	}
}
