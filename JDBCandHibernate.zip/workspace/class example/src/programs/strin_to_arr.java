package programs;

import java.util.Arrays;

public class strin_to_arr {
	public static void main(String[] args)
	{
		String s="bengaluru";
		char[] ch=s.toCharArray();
		for(int i=0;i<=s.length();i++)
		{
			Arrays.sort(ch);
		}
		System.out.println(ch);
	}
}
