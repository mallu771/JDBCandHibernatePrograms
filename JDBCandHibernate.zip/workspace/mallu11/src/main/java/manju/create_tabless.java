package manju;

import java.sql.*;

import java.util.Scanner;

public class create_tabless {
	public static void main(String[] args) throws Exception {
//		Scanner scanner=new Scanner(System.in);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/jehm31","root","ROOT");
		Statement statement=connection.createStatement();
		statement.execute("create table mock_details1(std_id integer primary key, std_name varchar(30), java_m_r varchar(50), sql_m_r varchar(50), web_m_r varchar(100), no_of_req integer)");
		System.out.println("create table");
		connection.close();
		}
}
