package manju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class engg_table {
	public static void main(String[] args) throws Exception {
		Scanner scanner=new Scanner(System.in);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/jehm31","root","ROOT");
		Statement statement=connection.createStatement();
		statement.execute("create table engg_detail(usn varchar(10) primary key, Name varchar(30), branch varchar(50), college_name varchar(50), CGPA varchar(100))");
		System.out.println("create table");
		connection.close();
		}
}
