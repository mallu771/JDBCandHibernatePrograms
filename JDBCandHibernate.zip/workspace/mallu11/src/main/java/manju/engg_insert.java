package manju;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.protocol.Resultset;

public class engg_insert {
public static void main(String[] args) throws Exception {
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/jehm31","root","ROOT");
	Scanner scanner=new Scanner(System.in);
	boolean flag=true;
	while(flag)
	{
		System.out.println("1.add students");
		System.out.println("2.update branch");
		System.out.println("3.Update cgpa");
		System.out.println("4.fetch the student");
		System.out.println("5.delete the students");
		System.out.println("6.fetch all the students");
		System.out.println("7.delete all the students");
		System.out.println("8.exit");
		System.out.println("chiose options......");
		switch(scanner.nextInt())
		{
		case 1:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("insert into engg_detail values(?,?,?,?,?)");
			System.out.println("enter the usn");
			preparedStatement.setString(1, scanner.next());
			System.out.println("enter the Name");
			preparedStatement.setString(2, scanner.next());
			System.out.println("enter the branch");
			preparedStatement.setString(3, scanner.next());
			System.out.println("enter the college name");
			preparedStatement.setString(4, scanner.next());
			System.out.println("enter the cgpa");
			preparedStatement.setString(5, scanner.next());
			preparedStatement.executeUpdate();
			System.out.println("student are insert");
			System.out.println("...................................");
		}
		break;
		case 2:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("update engg_detail set branch=? where usn=?");
			System.out.println("enter student usn");
			preparedStatement.setString(2, scanner.next());
			System.out.println("update branch");
			preparedStatement.setString(1, scanner.next());
			preparedStatement.executeUpdate();
			System.out.println("................................");
		}break;
		case 3:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("update engg_detail set CGPA=? where usn=?");
			System.out.println("enter student usn");
			preparedStatement.setString(2, scanner.next());
			System.out.println("update cgpa");
			preparedStatement.setString(1, scanner.next());
			preparedStatement.executeUpdate();
			System.out.println("..................................");
		}
		break;
		case 4:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("select * from engg_detail where usn=?");
			System.out.println("enter student usn");
			preparedStatement.setString(1, scanner.next());
			ResultSet resultset=preparedStatement.executeQuery();
			resultset.next();
			System.out.println("USN:"+ resultset.getString(1)+ " Name: "+resultset.getString(2) + " branch:" + resultset.getString(3)+ " college name:" + resultset.getString(4) + " CGPA:"+ resultset.getString(5));
			System.out.println("fetch student details");
			System.out.println("....................................");
		}
		break;
		case 5:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("delete from engg_detail where usn=?");
			System.out.println("enter student usn");
			preparedStatement.setString(1, scanner.next());
			System.out.println("delete values");
			preparedStatement.executeUpdate();
			System.out.println("....................................");
		}
		break;
		case 6:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("select * from engg_detail");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				
				System.out.println("USN:"+ resultSet.getString(1)+ " Name: "+resultSet.getString(2) + " branch:" + resultSet.getString(3)+ " college name:" + resultSet.getString(4) + " CGPA:"+ resultSet.getString(5));
			System.out.println("fetch all sudent details");
			System.out.println("..................................");
			}
		}
		break;
		case 7:
		{
			PreparedStatement preparedStatement=connection.prepareStatement("delete from engg_detail");
		   preparedStatement.executeUpdate();
			System.out.println("detele all the students details");
		}
		break;
		case 8:
		 {
			 flag=false;
			 System.out.println("........thank you .........");
		 }
		 break;
		 default:
			 System.out.println(".........invalid options........");
			 break;
		}
		}
		connection.close();
	}
}

