package manju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class insrt_value112 {
	
		public static void main(String[] args) throws SQLException {
			Scanner sc=new Scanner(System.in);
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/jehm31","root","ROOT");
			boolean flag=true;
			
			while(flag)
			{
				System.out.println("1.add student");
			System.out.println("2.update student java mock");
			  System.out.println("3.update number of req"); 
			System.out.println("4.delete the student");
			System.out.println("5.exit");
			System.out.println("Enter options");
			 switch(sc.nextInt())
			 {
			 case 1:
			 {
			PreparedStatement preparedStatement=connection.prepareStatement("insert into mock_details1 values(?,?,?,?,?,?)");
			System.out.println("enter id");
			preparedStatement.setInt(1, sc.nextInt());
			System.out.println("enter name");
			preparedStatement.setString(2, sc.next());
			System.out.println("enter java mock rating");
			preparedStatement.setString(3, sc.next());
			System.out.println("enter sql mock rating");
			preparedStatement.setString(4, sc.next());
			System.out.println("enter web mock rating");
			preparedStatement.setString(5, sc.next());
			System.out.println("enterno of req");
			preparedStatement.setInt(6, sc.nextInt());
	 		preparedStatement.executeUpdate();
			System.out.println("vales addeddd");
			}
			 break;
			 case 2:
			 {
				 PreparedStatement preparedStatement=connection.prepareStatement("update mock_details1 set java_m_r=? where std_id=?");
				 System.out.println("enter student id");
				 preparedStatement.setInt(2, sc.nextInt());
				 System.out.println("update java mock");
				 preparedStatement.setString(1, sc.next());
//				 System.out.println("update sql mock");
//				 preparedStatement.setString(3, sc.next());
//				 System.out.println("update web mock");
//				 preparedStatement.setString(4, sc.next());
 			 preparedStatement.executeUpdate();
				System.out.println("mock vales updated");
			 }
			 break;
			 case 3:
			 {
				 PreparedStatement preparedStatement=connection.prepareStatement("update mock_details1 set no_of_req=? where std_id=? ");
				 System.out.println("student id");
				  preparedStatement.setInt(2, sc.nextInt());
				 System.out.println("updatee requirements");
			  preparedStatement.setInt(1, sc.nextInt());
			  preparedStatement.executeUpdate();
				System.out.println("no of req updated..");
			 }
			 break;
			 case 4:
			 {
				 PreparedStatement preparedStatement=connection.prepareStatement("delete from mock_details1 where std_id=?");
			  System.out.println("delete student id");
			  preparedStatement.setInt(1, sc.nextInt());
			  preparedStatement.executeUpdate();
				System.out.println("staudent value deleted....");
			 }
			 break;
			 case 5:
			 {
				 flag=false;
				 System.out.println("thank you .........");
			 }
			 break;
			 default:
				 System.out.println("invalid optinsss");
				 break;
		}
	}
			connection.close();
		}
	}


