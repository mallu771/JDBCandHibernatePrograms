package com.mobile.other;
import com.mobile.mywhatsapp.whatsapp;
public class myfriend extends whatsapp
{
  public static void main(String[] args)
  {
	  myfriend m1= new myfriend();
	     //m1.pwd();
	    // m1.text();
	     m1.status();
	     m1.name();
  }

}

