package com.mobile.mywhatsapp;

public class whatsapp 
{
    private void pwd()
    {
    	System.out.println("whatsapp password");
    }
       void text()
       {
    	   System.out.println("whatsapp text");
       }
   protected void status()
       {
    	   System.out.println("whatsapp status");
       }
   public void name()
       {
    	   System.out.println("everyone");
       }
}
