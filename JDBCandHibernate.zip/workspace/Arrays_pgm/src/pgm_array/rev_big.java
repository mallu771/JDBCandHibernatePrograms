//
//import java.util.Scanner;
//public class insert {
//	    public static void main(String[] args) {
//	        Scanner scanner= new Scanner(System.in);
//	        String orgs = scanner.next();
//	        String strtobeInsrted = scanner.next();
//	        int m = scanner.nextInt();
//	        System.out.println("orignal string :"+ orgs);
//	        System.out.println("String to be inserted:"+strtobeInsrted);
//	        System.out.println("String to inserted at the index:"+m);
//
//	        System.out.println("Modified String:" +InsertString(orgs,strtobeInsrted,m));
//	    }
//
//	    private static String InsertString(String orgs, String strtobeInsrted, int index) {
//	        String newString = new String();
//	        for (int i = 0; i < orgs.length(); i++) {
//
//	            newString += orgs.charAt(i);
//	            if(i==index){
//	                newString += strtobeInsrted;
//	            }
//
//	        }
//	        return newString;
//	    }
//	}
//
