package equals_method123;

public class school {

			char grade;
			String name;
			int strength;
				
				school(char grade,String name,int strength)
				{
					this.grade=grade;
					this.name=name;
					this.strength=strength;
					
				}
				public boolean equals(Object obj)
				{
					school s2=(school) obj;
					return this.name==s2.name;
				}
				public static void main(String[] args) 
				{
				   school s1=new school('A',"xyw",1000);
				 
				  school s2=new school('B',"csk",500);
				  if(s1.equals(s2))
				  {
					  System.out.println("school name equals");
				  }
				  else
					  System.out.println("school name not equals");
				}
			}

