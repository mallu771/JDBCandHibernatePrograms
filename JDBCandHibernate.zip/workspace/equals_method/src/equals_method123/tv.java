package equals_method123;

public class tv {


			int cost;
			String brand;
			String type;
				
		       tv(int cost,String brand,String type)
				{
					this.cost=cost;
					this.brand=brand;
					this.type=type;
					
				}
				public boolean equals(Object obj)
				{
					tv t2=(tv) obj;
					return this.brand==t2.brand;
				}
				public static void main(String[] args) 
				{
				   tv t1=new tv(2424,"penasonic","smart tv");
				  
				  tv t2=new tv(6883,"led","color tv");
				  if(t1.equals(t2))
				  {
					  System.out.println("tv brand equals");
				  }
				  else
					  System.out.println("tv brand not equals");
				}
			}

