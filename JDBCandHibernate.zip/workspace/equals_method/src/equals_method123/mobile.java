package equals_method123;

public class mobile {
	double cost;
	String m_name;
	String color;
	
	mobile(double cost,String m_name,String color)
	{
		this.cost=cost;
		this.m_name=m_name;
		this.color=color;
		
	}
	public boolean equals(Object obj)
	{
		mobile m2=(mobile)obj;
		return this.m_name==m2.m_name;
	}
	public static void main(String[] args)
	{
		mobile m1=new mobile(2344.00,"Mi","red");
	 
	  mobile m2=new mobile(89794.00,"redmi","golden");
	     if(m1.equals(m2))
	     {
	    	 System.out.println("model name equals");
	     }
	     else
	    	 System.out.println("model name not equals");
	}
}
