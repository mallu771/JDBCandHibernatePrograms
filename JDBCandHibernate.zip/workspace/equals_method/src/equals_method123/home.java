package equals_method123;

public class home {

					String name;
					String color;
					int cost;
						
				 home(String name,String color,int cost)
						{
							this.name=name;
							this.color=color;
							this.cost=cost;
							
						}
						public boolean equals(Object obj)
						{
							home h2=(home) obj;
							return this.color==h2.color;
						}
						public static void main(String[] args) 
						{
						   home h1=new home("pornchandra","red",304775);
				
						  home h2=new home("amma","yellow",508978);
						 if(h1.equals(h2))
						 {
							 System.out.println("home color equals");
						 }
						 else 
							 System.out.println("home color not equals");
						}
					}


