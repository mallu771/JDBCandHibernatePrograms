package equals_method123;

public class laptop {
						String name;
						String brand;
						double cost;
							
					  laptop(String name,String brand,double cost)
							{
								this.name=name;
								this.brand=brand;
								this.cost=cost;
								
							}
							public boolean equals(Object obj)
							{
								laptop l2=(laptop) obj;
								return this.brand==l2.brand;
							}
							public static void main(String[] args) 
							{
							   laptop l1=new laptop("lenove","hp",34775);
							 
							  laptop l2=new laptop("hp","lenove",58978);
							 if(l1.equals(l2))
							 {
								 System.out.println("laptop brand equals");
							 }
							 else
								 System.out.println("laptop brand not equals");
							}
						}
