package equals_method123;

public class emp {
		int id;
		int sal;
		char grade;
							
			  emp(int id,int sal,char grade)
							{
								this.id=id;
								this.sal=sal;
								this.grade=grade;
								
							}
							public boolean equals(Object obj)
							{
								emp e2=(emp) obj;
								return this.sal==e2.sal;
							}
							public static void main(String[] args) 
							{
							  emp e1=new emp(1,23444,'A');
		
							 emp e2=new emp(2,74583,'B');
							  if(e1.equals(e2))
							  {
								  System.out.println("employee sal equals");
								  
							  }
							  else 
								  System.out.println("employee sal is not equals");
							}
						}


