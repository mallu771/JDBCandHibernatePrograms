package equals_method123;

public class course {
		
					
					String name;
					String u_name;
					double e_cost;
						
				  course(String name,String u_name,double e_cost)
						{
							this.name=name;
							this.u_name=u_name;
							this.e_cost=e_cost;
							
						}
						public boolean equals(Object obj)
						{
							course c2=(course) obj;
							return this.u_name==c2.u_name;
						}
						public static void main(String[] args) 
						{
						   course c1=new course("xya","vtu",72775);
						
						  course c2=new course("gty","vtu",98978);
						  if(c1.equals(c2))
						  {
							  System.out.println("course university equals");
						}
						  else
							  System.out.println("course university not equals");
					}



}
