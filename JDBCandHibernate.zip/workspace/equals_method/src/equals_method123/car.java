package equals_method123;

public class car {
			double cost;
			String m_name;
			String type;
			
			car(double cost,String m_name,String type)
			{
				this.cost=cost;
				this.m_name=m_name;
				this.type=type;
				
			}
			public boolean equals(Object obj)
			{
				car c2=(car) obj;
			       return this.m_name==c2.m_name;
			}
			public static void main(String[] args)
			{
				car c1=new car(37484.00,"bmw","red");
			  
			  car c2=new car(976394.00,"bmw","golden");
			  if(c1.equals(c2))
			  {
				  System.out.println("model name equals");
			  }
			  else
				  System.out.println("model name not equals");
			}
		}




