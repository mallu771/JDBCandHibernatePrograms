package equals_method123;

public class cloth {

			String color;
			int cost;
			int size;
								
				 cloth(String color,int cost,int size)
								{
							this.color=color;
							this.cost=cost;
							this.size=size;
									
								}
								public boolean equals(Object obj)
								{
									cloth c2=(cloth) obj;
									return this.cost==c2.cost;
								}
								public static void main(String[] args) 
								{
								  cloth c1=new cloth("red",4783,20*30);
								
								cloth c2=new cloth("yellow",8332,30*10);
								  if(c1.equals(c2))
								  {
									  System.out.println("cloth cost is equals");
								  }
								  else 
									  System.out.println("cloth cost not equals");
								}
}
