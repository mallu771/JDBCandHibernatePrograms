package equals_method123;

public class bike {
				int cost;
				String brand;
				String color;
					
     bike(int cost,String brand,String color)
					{
						this.cost=cost;
						this.brand=brand;
						this.color=color;
						
					}
					public boolean equals(Object obj)
					{
						
					bike b2=(bike) obj;
						return this.brand==b2.brand;
					}
					public static void main(String[] args) 
					{
					   bike b1=new bike(87673,"yamaha","red");
					 
					  bike b2=new bike(76883,"hero","black");
					 if(b1.equals(b2))
					 {
						 System.out.println("bike brand equals");
					 }
					 else
						 System.out.println("bike brand not equals");
					}
				}



