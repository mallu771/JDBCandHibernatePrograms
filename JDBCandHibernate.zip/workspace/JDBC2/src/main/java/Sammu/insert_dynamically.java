package Sammu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class insert_dynamically {
public static void main(String[] args) throws Exception {
	Scanner scanner=new Scanner(System.in);
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/anna","root","ROOT");
	PreparedStatement preparedStatement=connection.prepareStatement("insert into kushi values(?,?,?)");
	System.out.println("enter id");
	preparedStatement.setInt(1, scanner.nextInt());
	System.out.println("enter name");
	preparedStatement.setString(2, scanner.next());
	System.out.println("enter city");
	preparedStatement.setString(3, scanner.next());
	preparedStatement.executeUpdate();
	System.out.println("Added");
	connection.close();
}
}
