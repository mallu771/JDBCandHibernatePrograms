package Sammu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class update_value {
	public static void main(String[] args) throws Exception {
		Scanner scanner=new Scanner(System.in);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/anna","root","ROOT");
		PreparedStatement preparedStatement=connection.prepareStatement("update kushi set name=? where id=?");
		
		System.out.println("enter name");
		preparedStatement.setString(1, scanner.next());
		System.out.println("enter id");
		preparedStatement.setInt(2, scanner.nextInt());
		preparedStatement.executeUpdate();
		System.out.println("updateddd");
		connection.close();
	}
}
