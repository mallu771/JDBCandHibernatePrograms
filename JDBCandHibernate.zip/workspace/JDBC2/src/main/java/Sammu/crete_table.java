package Sammu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class crete_table {
public static void main(String[] args) throws Exception {
	
	Connection  connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/anna","root","ROOT");
   Statement statement=connection.createStatement();
   statement.execute("create table kushi(id integer primary key, name varchar(40), city varchar(30))");
  connection.close();
}
}