package Sammu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class delete_vales {
	public static void main(String[] args) throws Exception {
		Scanner scanner=new Scanner(System.in);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/anna","root","ROOT");
		PreparedStatement preparedStatement=connection.prepareStatement("delete from kushi where id=?");
		System.out.println("enter id");
		preparedStatement.setInt(1, scanner.nextInt());
		preparedStatement.executeUpdate();
		System.out.println("deleteddd");
		connection.close();
	}
}
