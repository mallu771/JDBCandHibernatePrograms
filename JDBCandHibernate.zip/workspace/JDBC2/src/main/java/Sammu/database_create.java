package Sammu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class database_create {
	public static void main(String[] args) throws Exception 
	{
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","ROOT");
		Statement statement=connection.createStatement();
		statement.execute("create database anna");
		connection.close();
		
}
}
