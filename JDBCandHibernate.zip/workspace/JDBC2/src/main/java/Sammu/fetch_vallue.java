package Sammu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class fetch_vallue {
	public static void main(String[] args) throws Exception {
		Scanner scanner=new Scanner(System.in);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/anna","root","ROOT");
		PreparedStatement preparedStatement=connection.prepareStatement("select * from kushi where id=?");
		
		System.out.println("enter id");
		preparedStatement.setInt(1, scanner.nextInt());
		ResultSet q=preparedStatement.executeQuery();
		q.next();
		System.out.println(q.getInt(1)+" "+q.getString(2)+" "+q.getString(3));
		
		connection.close();
	}
}
