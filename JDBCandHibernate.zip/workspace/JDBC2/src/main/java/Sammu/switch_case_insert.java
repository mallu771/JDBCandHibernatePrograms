package Sammu;

import java.sql.*;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class switch_case_insert {
	public static void main(String[] args) throws Exception {
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/anna","root","ROOT");
		Scanner scanner=new Scanner(System.in);
		boolean flag=true;
		while(flag)
		{
			System.out.println("1.Add name/n2.exit");
		switch(scanner.nextInt())
	{
			
	case 1:
	{	
		PreparedStatement preparedStatement=connection.prepareStatement("insert into kushi values(?,?,?)");
		System.out.println("enter id");
		preparedStatement.setInt(1, scanner.nextInt());
		System.out.println("enter name");
		preparedStatement.setString(2, scanner.next());
		System.out.println("enter city");
		preparedStatement.setString(3, scanner.next());
		preparedStatement.executeUpdate();
		System.out.println("Added");
	}
			break;
	case 2:
			{
				flag=false;
				System.out.println("thank you");
			}
			break;
	default :
			{
				System.out.println("invalid value");
		}
	}
	connection.close();
}
}
}
