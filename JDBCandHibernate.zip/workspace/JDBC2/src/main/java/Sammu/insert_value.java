package Sammu;
import java.sql.*;
import java.util.Scanner;

public class insert_value {
	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/jehm31","root","ROOT");
		boolean flag=true;
		
		while(flag)
		{
			System.out.println("1.add student/n2.update student java mock/n3.update number of req/n4.delete the student/n5.exit");
		   
		 switch(sc.nextInt())
		 {
		 case 1:
		 {
		PreparedStatement preparedStatement=connection.prepareStatement("insert into mock_details values(?,?,?,?,?,?)");
		System.out.println("enter id");
		preparedStatement.setInt(1, sc.nextInt());
		System.out.println("enter name");
		preparedStatement.setString(2, sc.next());
		System.out.println("enter java mock rating");
		preparedStatement.setString(3, sc.next());
		System.out.println("enter sql mock rating");
		preparedStatement.setString(4, sc.next());
		System.out.println("enter web mock rating");
		preparedStatement.setString(5, sc.next());
		System.out.println("enterno of req");
		preparedStatement.setInt(6, sc.nextInt());
 		preparedStatement.executeUpdate();
		System.out.println("vales addeddd");
		}
		 break;
		 case 2:
		 {
			 PreparedStatement preparedStatement=connection.prepareStatement("update mock_details set std_id=?)");
		     System.out.println("update java mock");
			 preparedStatement.setString(1, sc.next());
			 System.out.println("update sql mock");
			 preparedStatement.setString(2, sc.next());
			 System.out.println("update web mock");
			 preparedStatement.setString(3, sc.next());
			 preparedStatement.executeUpdate();
			System.out.println("mock vales updated");
		 }
		 break;
		 case 3:
		 {
			 PreparedStatement preparedStatement=connection.prepareStatement("update mock_details set std_id=? )");
		  System.out.println("updatee requirements");
		  preparedStatement.setInt(1, sc.nextInt());
		  preparedStatement.executeUpdate();
			System.out.println("no of req updated..");
		 }
		 break;
		 case 4:
		 {
			 PreparedStatement preparedStatement=connection.prepareStatement("delete from mock_details where std_id=?)");
		  System.out.println("delete student");
		  preparedStatement.setInt(1, sc.nextInt());
		  preparedStatement.executeUpdate();
			System.out.println("staudent value deleted....");
		 }
		 break;
		 case 5:
		 {
			 flag=false;
			 System.out.println("thank you .........");
		 }
		 break;
		 default:
			 System.out.println("invalid optinsss");
			 break;
	}
}
		connection.close();
	}
}
