package java22;

public class Armstrong {
	public static void main(String[] args){
  int n=143;
  int sum=0;
  int m=n;
  while(n!=0){
	  int rem=n%10;
	  Math.pow(rem,3);
	  sum+=(Math.pow(rem,3));
	  n=n/10;
  }
	 
	  
  if(m==sum){
	  System.out.println("armstrong");
	  
  }
  else
	  System.out.println("not armstrong");
	}
}
