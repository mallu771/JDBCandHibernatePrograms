package one_to_one;

import javax.persistence.*;

@Entity
public class Pancard{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int pid;
	String pannumber;
	String address;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPannumber() {
		return pannumber;
	}
	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}


@Entity
class person {
	@Id
int id;
String name;
@OneToOne
Pancard o;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Pancard getO() {
	return o;
}
public void setO(Pancard o) {
	this.o = o;
}
}


public class Mainclass {
	public static void main(String[] args) 
{		
EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
EntityManager entityManager=entityManagerFactory.createEntityManager();
EntityTransaction entityTransaction=entityManager.getTransaction();

Pancard one=new Pancard();
one.setAddress("mysore");
one.setPannumber("1543dkhd");

person person=new person();
person.setName("mahesh");
person.setO(one);

entityTransaction.begin();
entityManager.persist(one);
entityManager.persist(person);
entityTransaction.commit();
	}
}
