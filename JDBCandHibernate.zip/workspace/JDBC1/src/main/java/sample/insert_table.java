package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class insert_table {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mgb","root","ROOT");
	    Statement st=conn.createStatement();
		st.execute("insert into chinari value(25,'OKK')");
		st.execute("insert into chinari value(21,'sachi')");
		st.execute("insert into chinari value(31,'mallu')");
		st.execute("insert into chinari value(41,'dhoni')");
		st.execute("insert into chinari value(51,'kohli')");
		st.execute("insert into chinari value(61,'harsha')");
		conn.close();
		System.out.println("inserted the values");
}
}
