package sample;

import java.sql.*;

public class demo {
public static void main(String[] args) throws Exception {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mgb","root","ROOT");
    Statement st=conn.createStatement();
	boolean e=st.execute("Create table chinari(id integer primary key,name varchar(20)");
	
	
	conn.close();
	System.out.println("database is created");
	
}
}
