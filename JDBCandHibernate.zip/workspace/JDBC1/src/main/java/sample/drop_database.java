package sample;
import java.sql.*;
public class drop_database {
public static void main(String[] args) throws Exception {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mallu","root","ROOT");
	Statement statement=connection.createStatement();
	statement.executeUpdate("drop database mallu");
	connection.close();
	System.out.println("table database");
}
}
