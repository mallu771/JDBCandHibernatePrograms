package sample;
import java.sql.*;
public class update_value {
public static void main(String[] args) throws Exception {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mgb","root","ROOT");
    Statement statement=connection.createStatement();
    statement.executeUpdate("Update chinari set name='chinari' where id=41");
    connection.close();
    System.out.println("data updated");
}

}
