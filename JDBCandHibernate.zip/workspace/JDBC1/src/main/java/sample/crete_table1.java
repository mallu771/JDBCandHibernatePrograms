package sample;
import java.sql.*;
public class crete_table1 {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/god","root","ROOT");
	    Statement st=conn.createStatement();
		st.execute("Create table huli(id integer primary key, name varchar(20))");
		conn.close();
		System.out.println("table is created");
		
	}
	}


