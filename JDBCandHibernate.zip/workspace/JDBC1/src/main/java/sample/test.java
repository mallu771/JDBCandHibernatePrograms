package sample;
import java.sql.*;
public class test {
	public static void main(String[] args) throws Exception {
  Class.forName("com.mysql.cj.jdbc.Driver");
  Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mgb","root","ROOT");
  Statement statement=connection.createStatement();
  ResultSet e=statement.executeQuery("select * from chinari where id=41 ");
  e.next();
  System.out.println(e.getInt(1)+" "+e.getString(2));
  connection.close();
}
}
