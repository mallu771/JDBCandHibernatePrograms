package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class delete_data {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mgb","root","ROOT");
	    Statement st=conn.createStatement();
		st.executeUpdate("delete from chinari where id=61");
		st.executeUpdate("delete from chinari where id=20");
		System.out.println("delete data");
}
}
