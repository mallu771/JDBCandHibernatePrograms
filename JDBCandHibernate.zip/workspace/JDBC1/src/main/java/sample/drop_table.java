package sample;
import java.sql.*;
public class drop_table {
public static void main(String[] args) throws Exception {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/god","root","ROOT");
	Statement  statement=connection.createStatement();
	statement.executeUpdate("drop table huli");
	connection.close();
}
}
