package One_to_one;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Persistence;

@Entity
class Pancard{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int pid;
	String Pnumber;
	String address;
	@OneToOne
	Person p;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPnumber() {
		return Pnumber;
	}
	public void setPnumber(String pnumber) {
		Pnumber = pnumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Person getP() {
		return p;
	}
	public void setP(Person p) {
		this.p = p;
	}
}
@Entity
class Person{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		
	}
	Pancard p;
	public Pancard getP() {
		return p;
	}
	public void setP(Pancard p) {
		this.p = p;
	}
	
}
public class Driver {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	Pancard pancard=new Pancard();
	pancard.setAddress("belagavi");
	pancard.setPnumber("12121ghj");
	
	Person person=new Person();
	person.setName("kallu");
	person.setP(pancard);
	entityTransaction.begin();
	entityManager.persist(pancard);
	entityManager.persist(person);
	entityTransaction.commit();
}
}
