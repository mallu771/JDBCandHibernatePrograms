package Many_to_one;

import javax.persistence.*;


@Entity
class Train{
	@Id
	String t_name;

	public String getT_name() {
		return t_name;
	}

	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
}
@Entity
class Passenger
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	@ManyToOne
	Train t;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Train getT() {
		return t;
	}
	public void setT(Train t) {
		this.t = t;
	}	
}
public class Driver {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	Train train=new Train();
	train.setT_name("Mysore Express");
	Passenger passenger=new Passenger();
	passenger.setName("Ramesh");
	passenger.setT(train);
	Passenger passenger1=new Passenger();
	passenger.setName("Mahesh");
	passenger.setT(train);
	Passenger passenger2=new Passenger();
	passenger.setName("Lokesh");
	passenger.setT(train);
	entityTransaction.begin();
	entityManager.persist(train);
	entityManager.persist(passenger);
	entityManager.persist(passenger1);
	entityManager.persist(passenger2);

	entityTransaction.commit();
}
}
