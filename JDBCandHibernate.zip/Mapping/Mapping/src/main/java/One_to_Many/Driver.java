package One_to_Many;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
class Student
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	@OneToMany
	List<InstaAccount> i;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<InstaAccount> getI() {
		return i;
	}
	public void setI(List<InstaAccount> i) {
		this.i = i;
	}
	
}
@Entity
class InstaAccount{
	@Id
	String instaname;

	public String getInstaname() {
		return instaname;
	}

	public void setInstaname(String instaname) {
		this.instaname = instaname;
	}
	
}


public class Driver {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		Student student=new Student();
		student.setName("Ramesh");
		InstaAccount account=new InstaAccount();
		account.setInstaname("Ravi");
		
		InstaAccount account2=new  InstaAccount();
		account2.setInstaname("Lokesh");
		InstaAccount account3=new InstaAccount();
		account3.setInstaname("Mahesh");
		List<InstaAccount> i=new ArrayList<InstaAccount>();
		i.add(account);
		i.add(account2);
		i.add(account3);
		student.setI(i);
		entityTransaction.begin();
		entityManager.persist(student);
		entityManager.persist(account);
		entityManager.persist(account2);
		entityManager.persist(account3);
		entityTransaction.commit();
		
	}

}
