package ManyToMany;

import java.util.*;
import javax.persistence.*;

@Entity
class TouristPlace
{
	@Id
	String palce;
	@ManyToMany
	List<Traveller> t;
	public String getPalce() {
		return palce;
	}
	public void setPalce(String palce) {
		this.palce = palce;
	}
	public List<Traveller> getT() {
		return t;
	}
	public void setT(List<Traveller> t) {
		this.t = t;
	}
	
	
}
@Entity
class Traveller
{
	@Id
	String tname;
	@ManyToMany
	List<TouristPlace> tp;
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public List<TouristPlace> getTp() {
		return tp;
	}
	public void setTp(List<TouristPlace> tp) {
		this.tp = tp;
	}
	
}
public class Driver {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	TouristPlace  place=new TouristPlace();
	place.setPalce("belagavi");
	TouristPlace  place1=new TouristPlace();
	place1.setPalce("tumkur");
	TouristPlace  place2=new TouristPlace();
	place2.setPalce("gulbarga");

	List< TouristPlace> l=new ArrayList<TouristPlace>();
	l.add(place);
	l.add(place1);
	l.add(place2);
	
	Traveller traveller=new Traveller();
	traveller.setTname("Mallu");
	Traveller traveller1=new Traveller();
	traveller1.setTname("Kallu");
	Traveller traveller2=new Traveller();
	traveller2.setTname("Ballu");
	
	List<Traveller> l1=new ArrayList<Traveller>();
	l1.add(traveller);
	l1.add(traveller1);
	l1.add(traveller2);
	
	place.setT(l1);
	place1.setT(l1);
	place.setT(l1);
	
	traveller.setTp(l);
	traveller1.setTp(l);
	traveller2.setTp(l);
	
	entityTransaction.begin();
	entityManager.persist(traveller);
	entityManager.persist(traveller1);
	entityManager.persist(traveller2);
	entityManager.persist(place2);
	entityManager.persist(place1);
	entityManager.persist(place);
	entityTransaction.commit();	
	
}
}
