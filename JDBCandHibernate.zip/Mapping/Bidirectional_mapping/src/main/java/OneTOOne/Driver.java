package OneTOOne;

import javax.persistence.*;
@Entity
class Person
{ 
	@Id
	String name;
	@OneToOne
	Pancard p;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Pancard getP() {
		return p;
	}
	public void setP(Pancard p) {
		this.p = p;
	}
}
@Entity
class Pancard
{
	@Id
	String panNumber;
	@OneToOne
	Person person;
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
}
public class Driver 
{
public static void main(String[] args) 
{
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	Pancard pancard=new Pancard();
	pancard.setPanNumber("123jshd");
	Person person=new Person();
	person.setName("Ramesh");
	pancard.setPerson(person);
	person.setP(pancard);
	entityTransaction.begin();
	entityManager.persist(pancard);
	entityManager.persist(person);
	entityTransaction.commit();
}
}
