package OneTOManyandManyToOne;

import java.util.*;


import javax.persistence.*;

@Entity
class student
{
	@Id
	String Name;
	@OneToMany
	List<Insta> l;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public List<Insta> getL() {
		return l;
	}
	public void setL(List<Insta> l) {
		this.l = l;
	}
	
}
@Entity
class Insta
{
	@Id
	String Iname;
	@ManyToOne
	student t;
	public String getIname() {
		return Iname;
	}
	public void setIname(String iname) {
		Iname = iname;
	}
	public student getT() {
		return t;
	}
	public void setT(student t) {
		this.t = t;
	}
	
}

public class Driver {
public static void main(String[] args) {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	student s=new student();
	s.setName("Ramesh");
	
	Insta insta=new Insta();
	insta.setIname("mukundha");
	insta.setT(s);
	Insta insta1=new Insta();
	insta1.setIname("Mallu");
	insta1.setT(s);
	Insta insta2=new Insta();
	insta2.setIname("Deepa_P");
	insta2.setT(s);
	List<Insta> i=new ArrayList<Insta>();
	i.add(insta);
	i.add(insta1);
	i.add(insta2);
	s.setL(i);
	entityTransaction.begin();
	entityManager.persist(insta2);
	entityManager.persist(insta1);
	entityManager.persist(insta);
	entityManager.persist(s);
	entityTransaction.commit();
}
}
